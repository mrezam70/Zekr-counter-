package com.example.zekr.data.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import com.example.zekr.data.local.ThemeEntity
import com.example.zekr.ui.theme.BuiltInThemes
import com.example.zekr.ui.theme.TextDark
import com.example.zekr.ui.theme.TextLight
import org.json.JSONException
import org.json.JSONObject

sealed class ParseResult {
    data class Ok(val theme: ThemeEntity) : ParseResult()
    data class Invalid(val reason: String) : ParseResult()
    data class Contrast(val reason: String) : ParseResult()
}

/**
 * خواندن و اعتبارسنجی فایل تم (JSON). فقط رنگ‌ها پذیرفته می‌شوند و
 * خوانایی رنگ‌ها بررسی می‌شود تا تم خراب یا مخرب، برنامه را ناخوانا نکند.
 * قالب فایل در docs/THEME_FORMAT.md توضیح داده شده است.
 */
object ThemeParser {
    private val idRegex = Regex("^[a-z0-9][a-z0-9-]{2,39}$")
    private val hexRegex = Regex("^#[0-9A-Fa-f]{6}$")

    private val colorKeys = listOf(
        "primary", "primaryDark", "background", "container",
        "onContainer", "containerDark", "onContainerDark", "backgroundDark",
    )

    fun parse(text: String, lang: String, sourceUrl: String?): ParseResult {
        val root = try {
            JSONObject(text)
        } catch (e: JSONException) {
            return ParseResult.Invalid("JSON")
        }
        if (root.optInt("schema", -1) != 1) return ParseResult.Invalid("schema")

        val id = root.optString("id")
        if (!idRegex.matches(id)) return ParseResult.Invalid("id")
        if (BuiltInThemes.byId(id) != null) return ParseResult.Invalid("id (reserved)")

        val name = readName(root, lang) ?: return ParseResult.Invalid("name")

        val colors = root.optJSONObject("colors") ?: return ParseResult.Invalid("colors")
        val parsed = HashMap<String, Color>()
        for (key in colorKeys) {
            val raw = colors.optString(key)
            if (!hexRegex.matches(raw)) return ParseResult.Invalid("colors.$key")
            parsed[key] = Color((0xFF000000L or raw.substring(1).toLong(16)).toInt())
        }
        fun c(k: String) = parsed.getValue(k)

        val white = Color.White
        val checks = listOf(
            Triple("primary", ratio(white, c("primary")), 3.0),
            Triple("primaryDark", ratio(white, c("primaryDark")), 3.0),
            Triple("container / onContainer", ratio(c("onContainer"), c("container")), 4.5),
            Triple("containerDark / onContainerDark", ratio(c("onContainerDark"), c("containerDark")), 4.5),
            Triple("background", ratio(TextLight, c("background")), 7.0),
            Triple("backgroundDark", ratio(TextDark, c("backgroundDark")), 7.0),
            Triple("primaryDark / backgroundDark", ratio(c("primaryDark"), c("backgroundDark")), 3.0),
        )
        checks.firstOrNull { it.second < it.third }?.let { return ParseResult.Contrast(it.first) }

        return ParseResult.Ok(
            ThemeEntity(
                id = id,
                name = name,
                primary = c("primary").toArgb(),
                primaryDark = c("primaryDark").toArgb(),
                background = c("background").toArgb(),
                container = c("container").toArgb(),
                onContainer = c("onContainer").toArgb(),
                containerDark = c("containerDark").toArgb(),
                onContainerDark = c("onContainerDark").toArgb(),
                backgroundDark = c("backgroundDark").toArgb(),
                sourceUrl = sourceUrl,
            ),
        )
    }

    /** نام می‌تواند یک متن یا یک نقشه زبان→نام باشد. */
    private fun readName(root: JSONObject, lang: String): String? {
        val raw = root.opt("name")
        val picked = when (raw) {
            is String -> raw
            is JSONObject -> raw.optString(lang).ifBlank { raw.optString("en") }
                .ifBlank { raw.keys().asSequence().firstOrNull()?.let { raw.optString(it) }.orEmpty() }
            else -> ""
        }
        val clean = picked.filter { !it.isISOControl() }.trim()
        return clean.takeIf { it.length in 1..30 }
    }

    /** نسبت کنتراست WCAG بین دو رنگ. */
    fun ratio(a: Color, b: Color): Double {
        val la = a.luminance().toDouble()
        val lb = b.luminance().toDouble()
        val hi = maxOf(la, lb)
        val lo = minOf(la, lb)
        return (hi + 0.05) / (lo + 0.05)
    }
}
