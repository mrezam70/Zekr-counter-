package com.example.zekr.data.repo

import androidx.room.withTransaction
import com.example.zekr.data.local.AppDatabase
import com.example.zekr.data.local.CounterState
import com.example.zekr.data.local.CounterUndo
import com.example.zekr.data.local.OutboxEntry
import com.example.zekr.data.local.SessionHistory
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject
import java.util.UUID

/**
 * منطق شمارنده. هر عملیات داخل یک تراکنش انجام می‌شود تا حتی با لمس‌های خیلی سریع،
 * هیچ شمارشی گم نشود. همه‌چیز اول روی گوشی ذخیره می‌شود؛ هر جلسه تمام‌شده هم در صف
 * ارسال به سرور ([OutboxEntry]) ثبت می‌شود و بعداً (با ورود کاربر و اینترنت) ارسال می‌شود.
 */
class CounterRepository(
    private val db: AppDatabase,
    private val onOutboxChanged: () -> Unit = {},
) {
    private val counter = db.counterDao()
    private val sessions = db.sessionDao()
    private val dhikr = db.dhikrDao()
    private val outbox = db.outboxDao()

    fun observeState(): Flow<CounterState?> = counter.observe()
    fun observeUndoCount(): Flow<Int> = counter.observeUndoCount()

    /** اگر هنوز وضعیتی ساخته نشده، با اولین ذکر شروع می‌کند. */
    suspend fun ensureState() = db.withTransaction {
        if (counter.get() == null) {
            val first = dhikr.getFirst() ?: return@withTransaction
            counter.save(CounterState(dhikrId = first.id, goal = first.suggestedCount))
        }
    }

    suspend fun increment() = db.withTransaction {
        val s = counter.get() ?: return@withTransaction
        if (s.count >= MAX_COUNT) return@withTransaction
        pushUndo(s.count)
        counter.save(s.copy(count = s.count + 1, startedAt = s.startedAt ?: now()))
    }

    suspend fun undo() = db.withTransaction {
        val u = counter.peekUndo() ?: return@withTransaction
        val s = counter.get() ?: return@withTransaction
        counter.deleteUndo(u.id)
        counter.save(
            s.copy(
                count = u.previousCount,
                startedAt = if (u.previousCount == 0) null else s.startedAt,
            ),
        )
    }

    /** ویرایش دستی عدد. قابل برگرداندن است. */
    suspend fun setCount(n: Int) = db.withTransaction {
        val s = counter.get() ?: return@withTransaction
        val value = n.coerceIn(0, MAX_COUNT)
        if (value == s.count) return@withTransaction
        pushUndo(s.count)
        counter.save(
            s.copy(
                count = value,
                startedAt = if (value == 0) null else (s.startedAt ?: now()),
            ),
        )
    }

    /** صفر کردن. قابل برگرداندن است و قفل ریست دوباره بسته می‌شود. */
    suspend fun reset() = db.withTransaction {
        val s = counter.get() ?: return@withTransaction
        if (s.count == 0) return@withTransaction
        pushUndo(s.count)
        counter.save(s.copy(count = 0, startedAt = null, resetLocked = true))
    }

    suspend fun setLocked(locked: Boolean) = db.withTransaction {
        val s = counter.get() ?: return@withTransaction
        counter.save(s.copy(resetLocked = locked))
    }

    /** پایان جلسه: ثبت در تاریخچه و صفر کردن. اگر چیزی شمرده نشده باشد false برمی‌گرداند. */
    suspend fun endSession(): Boolean {
        val ok = db.withTransaction {
            val s = counter.get() ?: return@withTransaction false
            if (s.count <= 0) return@withTransaction false
            archive(s)
            counter.clearUndo()
            counter.save(s.copy(count = 0, startedAt = null))
            true
        }
        if (ok) onOutboxChanged()
        return ok
    }

    /** شروع شمارش یک ذکر با هدف و نیت. اگر شمارش قبلی نیمه‌کاره بود، در تاریخچه ثبت می‌شود. */
    suspend fun start(dhikrId: Long, goal: Int, intention: String?) {
        val archived = db.withTransaction {
            val old = counter.get()
            val hadCount = old != null && old.count > 0
            if (old != null && hadCount) archive(old)
            counter.clearUndo()
            counter.save(
                CounterState(
                    dhikrId = dhikrId,
                    goal = goal.coerceIn(1, MAX_COUNT),
                    intention = intention?.trim()?.takeIf { it.isNotEmpty() },
                    resetLocked = old?.resetLocked ?: true,
                ),
            )
            hadCount
        }
        if (archived) onOutboxChanged()
    }

    /** جلسه را در تاریخچه و در صف ارسال به سرور ثبت می‌کند (داخل تراکنش صدا زده می‌شود). */
    private suspend fun archive(s: CounterState) {
        val end = now()
        val begin = s.startedAt ?: end
        val id = UUID.randomUUID().toString()
        val durationSec = ((end - begin) / 1000).toInt().coerceAtLeast(1)
        sessions.insert(
            SessionHistory(
                id = id,
                dhikrId = s.dhikrId,
                khatmId = s.khatmId,
                count = s.count,
                goal = s.goal,
                durationSec = durationSec,
                startedAt = begin,
                endedAt = end,
                syncState = "pending",
            ),
        )
        // ذکرهای آماده با کلید معرفی می‌شوند؛ ذکر دلخواه فعلاً با شناسه محلی
        val ref = dhikr.getById(s.dhikrId)?.builtinKey ?: "custom:${s.dhikrId}"
        val payload = JSONObject()
            .put("id", id)
            .put("dhikrRef", ref)
            .put("khatmId", s.khatmId ?: JSONObject.NULL)
            .put("count", s.count)
            .put("goal", s.goal)
            .put("durationSec", durationSec)
            .put("startedAt", begin)
            .put("endedAt", end)
        outbox.insert(OutboxEntry(type = "session", payloadJson = payload.toString()))
    }

    private suspend fun pushUndo(previous: Int) {
        counter.pushUndo(CounterUndo(previousCount = previous))
        counter.trimUndo()
    }

    private fun now() = System.currentTimeMillis()

    companion object {
        const val MAX_COUNT = 1_000_000
    }
}
