package com.example.zekr.feature.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.zekr.R
import com.example.zekr.core.formatLocalized
import com.example.zekr.core.toLocalizedDigits
import com.example.zekr.data.repo.DhikrRepository
import com.example.zekr.data.repo.SessionRepository
import com.example.zekr.feature.library.nameOf
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StatsScreen(sessions: SessionRepository, dhikrRepo: DhikrRepository) {
    val vm: StatsViewModel = viewModel(factory = StatsViewModel.factory(sessions, dhikrRepo))
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language
    val result = ui.result

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !ui.monthly,
                onClick = { vm.setMonthly(false) },
                label = { Text(stringResource(R.string.stats_weekly)) },
            )
            FilterChip(
                selected = ui.monthly,
                onClick = { vm.setMonthly(true) },
                label = { Text(stringResource(R.string.stats_monthly)) },
            )
        }

        if (result == null || !result.hasData) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Text(
                    text = stringResource(R.string.stats_empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                )
            }
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                label = stringResource(R.string.stat_streak),
                value = stringResource(R.string.days_count, result.streak.toLocalizedDigits(lang)),
                filled = true,
                modifier = Modifier.weight(1f),
            )
            StatCard(
                label = stringResource(R.string.stat_record),
                value = stringResource(R.string.days_count, result.record.toLocalizedDigits(lang)),
                filled = false,
                modifier = Modifier.weight(1f),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(
                label = stringResource(R.string.stat_total),
                value = result.total.formatLocalized(lang),
                filled = false,
                modifier = Modifier.weight(1f),
            )
            StatCard(
                label = stringResource(R.string.stat_avg),
                value = result.average.formatLocalized(lang),
                filled = true,
                modifier = Modifier.weight(1f),
            )
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                val max = result.bars.maxOf { it.total }.coerceAtLeast(1)
                Row(
                    modifier = Modifier.fillMaxWidth().height(150.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    result.bars.forEach { bar ->
                        val highlight = bar.total == max && bar.total > 0
                        Column(
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                        ) {
                            Text(
                                text = bar.total.formatLocalized(lang),
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height((bar.total.toFloat() / max * 96f).coerceAtLeast(2f).dp)
                                    .background(
                                        if (highlight) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.primaryContainer,
                                        RoundedCornerShape(5.dp),
                                    ),
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    result.bars.forEach { bar ->
                        val label = bar.date?.dayOfWeek?.getDisplayName(TextStyle.NARROW, Locale(lang))
                            ?: stringResource(R.string.week_short, (bar.index + 1).toLocalizedDigits(lang))
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }

        if (result.top.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.stat_top), style = MaterialTheme.typography.titleSmall)
                    val topMax = result.top.first().total.coerceAtLeast(1)
                    result.top.forEach { item ->
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Text(ui.dhikr[item.dhikrId]?.nameOf(ctx) ?: "—", fontSize = 13.sp)
                                Text(
                                    item.total.formatLocalized(lang),
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            LinearProgressIndicator(
                                progress = { item.total.toFloat() / topMax },
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(7.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, filled: Boolean, modifier: Modifier = Modifier) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
    val fg: Color = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer
    Card(colors = CardDefaults.cardColors(containerColor = bg), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, fontSize = 12.sp, color = fg.copy(alpha = 0.9f))
            Text(value, fontSize = 21.sp, color = fg, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
