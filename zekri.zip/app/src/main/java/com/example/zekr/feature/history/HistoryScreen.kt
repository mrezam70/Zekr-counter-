package com.example.zekr.feature.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.zekr.R
import com.example.zekr.core.dayLabel
import com.example.zekr.core.durationLabel
import com.example.zekr.core.formatLocalized
import com.example.zekr.core.timeLabel
import com.example.zekr.core.toDate
import com.example.zekr.data.repo.DhikrRepository
import com.example.zekr.data.repo.SessionRepository
import com.example.zekr.data.sync.SyncRepository
import com.example.zekr.feature.library.nameOf
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun HistoryScreen(sessions: SessionRepository, dhikrRepo: DhikrRepository, sync: SyncRepository) {
    val vm: HistoryViewModel = viewModel(factory = HistoryViewModel.factory(sessions, dhikrRepo, sync))
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)

    val todays = ui.sessions.filter { toDate(it.endedAt, zone) == today }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            val (icon, text) = when {
                !ui.loggedIn -> Icons.Filled.CloudOff to stringResource(R.string.sync_local)
                ui.pending > 0 -> Icons.Filled.CloudUpload to
                    stringResource(R.string.sync_waiting, ui.pending.formatLocalized(lang))
                else -> Icons.Filled.CloudDone to stringResource(R.string.sync_done)
            }
            SyncStatus(icon, text)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryCard(
                    label = stringResource(R.string.sessions_today),
                    value = todays.size.formatLocalized(lang),
                    filled = true,
                    modifier = Modifier.weight(1f),
                )
                SummaryCard(
                    label = stringResource(R.string.total_today),
                    value = todays.sumOf { it.count }.formatLocalized(lang),
                    filled = false,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        if (ui.sessions.isEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.history_empty),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                )
            }
        }
        items(ui.sessions, key = { it.id }) { s ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Filled.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(
                            text = ui.dhikr[s.dhikrId]?.nameOf(ctx) ?: "—",
                            style = MaterialTheme.typography.titleSmall,
                        )
                        Text(
                            text = dayLabel(ctx, toDate(s.endedAt, zone), today, lang) + " · " +
                                timeLabel(s.endedAt, zone, lang) + " · " +
                                durationLabel(ctx, s.durationSec, lang),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text(
                        text = s.count.formatLocalized(lang) + " / " + s.goal.formatLocalized(lang),
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleSmall,
                    )
                }
            }
        }
    }
}

@Composable
private fun SyncStatus(icon: ImageVector, text: String) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(
                text = text,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(start = 12.dp),
            )
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, filled: Boolean, modifier: Modifier = Modifier) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
    val fg = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer
    Card(colors = CardDefaults.cardColors(containerColor = bg), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, fontSize = 12.sp, color = fg.copy(alpha = 0.9f))
            Text(value, fontSize = 22.sp, color = fg, modifier = Modifier.padding(top = 4.dp))
        }
    }
}
