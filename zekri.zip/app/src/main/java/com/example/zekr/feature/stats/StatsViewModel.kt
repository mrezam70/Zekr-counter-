package com.example.zekr.feature.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.zekr.data.local.DhikrWithTranslations
import com.example.zekr.data.repo.DhikrRepository
import com.example.zekr.data.repo.SessionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.ZoneId

data class StatsUi(
    val monthly: Boolean = false,
    val result: StatsResult? = null,
    val dhikr: Map<Long, DhikrWithTranslations> = emptyMap(),
)

class StatsViewModel(sessions: SessionRepository, dhikrRepo: DhikrRepository) : ViewModel() {
    private val monthly = MutableStateFlow(false)

    val ui: StateFlow<StatsUi> = combine(
        sessions.observeAll(),
        dhikrRepo.observeAll(),
        monthly,
    ) { list, dhikr, m ->
        val zone = ZoneId.systemDefault()
        StatsUi(
            monthly = m,
            result = StatsCalculator.compute(list, m, LocalDate.now(zone), zone),
            dhikr = dhikr.associateBy { it.dhikr.id },
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUi())

    fun setMonthly(value: Boolean) {
        monthly.value = value
    }

    companion object {
        fun factory(sessions: SessionRepository, dhikrRepo: DhikrRepository) =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    StatsViewModel(sessions, dhikrRepo) as T
            }
    }
}
