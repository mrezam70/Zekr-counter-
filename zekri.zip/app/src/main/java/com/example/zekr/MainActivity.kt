package com.example.zekr

import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.example.zekr.data.settings.DarkMode
import com.example.zekr.data.theme.resolvePalette
import com.example.zekr.ui.navigation.ZekrRoot
import com.example.zekr.ui.theme.ZekrTheme
import kotlinx.coroutines.launch

// AppCompatActivity لازم است تا تغییر زبان برنامه روی همه نسخه‌های اندروید کار کند.
class MainActivity : AppCompatActivity() {

    private val container get() = (application as ZekrApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // نوار بالای برنامه همیشه رنگی (تیره) است، پس آیکون‌های نوار وضعیت روشن می‌مانند.
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT))
        setContent {
            val settings by container.settingsRepo.state.collectAsStateWithLifecycle()
            val custom by container.themeRepo.custom.collectAsStateWithLifecycle(initialValue = emptyList())
            val palette = remember(settings.themeId, custom) { resolvePalette(settings.themeId, custom) }
            val dark = when (settings.darkMode) {
                DarkMode.SYSTEM -> isSystemInDarkTheme()
                DarkMode.LIGHT -> false
                DarkMode.DARK -> true
            }
            ZekrTheme(palette = palette, darkTheme = dark) {
                ZekrRoot()
            }
        }
    }

    /** شمارش با دکمه‌های ولوم: فقط وقتی تنظیم روشن است و صفحه شمارش جلوی کاربر است. */
    private fun volumeCountingActive(keyCode: Int): Boolean =
        (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) &&
            container.settingsRepo.state.value.volumeKeys &&
            container.counterScreenActive

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (volumeCountingActive(keyCode)) {
            if (event.repeatCount == 0) {
                lifecycleScope.launch { container.counterRepo.increment() }
                if (container.settingsRepo.state.value.vibration) {
                    window.decorView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (volumeCountingActive(keyCode)) return true
        return super.onKeyUp(keyCode, event)
    }
}
