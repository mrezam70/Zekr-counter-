package com.example.zekr.ui.theme

import androidx.annotation.StringRes
import androidx.compose.ui.graphics.Color
import com.example.zekr.R

/**
 * یک تم رنگی (هم حالت روشن، هم تیره).
 *
 * p  = رنگ اصلی (روشن)        q  = رنگ اصلی (تیره)
 * l  = پس‌زمینه روشن          m  = کانتینر روشن (چیپ و کارت‌های رنگی)
 * d  = متن روی کانتینر روشن    x8 = کانتینر تیره
 * x1 = متن روی کانتینر تیره    x9 = پس‌زمینه تیره
 */
data class ThemePalette(
    val id: String,
    val p: Color,
    val q: Color,
    val l: Color,
    val m: Color,
    val d: Color,
    val x8: Color,
    val x1: Color,
    val x9: Color,
)

/** سه تم آماده برنامه. تم‌های دانلودی در دیتابیس ذخیره می‌شوند. */
object BuiltInThemes {
    val green = ThemePalette(
        "green", Color(0xFF0F6E56), Color(0xFF1D9E75), Color(0xFFE1F5EE), Color(0xFF9FE1CB),
        Color(0xFF085041), Color(0xFF085041), Color(0xFF9FE1CB), Color(0xFF04342C),
    )
    val blue = ThemePalette(
        "blue", Color(0xFF185FA5), Color(0xFF378ADD), Color(0xFFE6F1FB), Color(0xFFB5D4F4),
        Color(0xFF0C447C), Color(0xFF0C447C), Color(0xFFB5D4F4), Color(0xFF042C53),
    )
    val amber = ThemePalette(
        "amber", Color(0xFF854F0B), Color(0xFFBA7517), Color(0xFFFAEEDA), Color(0xFFFAC775),
        Color(0xFF633806), Color(0xFF633806), Color(0xFFFAC775), Color(0xFF412402),
    )

    val all = listOf(green, blue, amber)

    fun byId(id: String): ThemePalette? = all.firstOrNull { it.id == id }

    @StringRes
    fun nameRes(id: String): Int? = when (id) {
        "green" -> R.string.theme_green
        "blue" -> R.string.theme_blue
        "amber" -> R.string.theme_amber
        else -> null
    }
}
