package com.example.zekr.core

private val arabicMarks = Regex("[\\u064B-\\u065F\\u0670]")

/** برای جستجو: اعراب را حذف و ی و ک را یکسان می‌کند. */
fun String.normalizeArabic(): String =
    replace(arabicMarks, "").replace('ي', 'ی').replace('ك', 'ک').lowercase()

/** رقم‌های فارسی و عربی را به رقم انگلیسی تبدیل می‌کند (برای خواندن ورودی کاربر). */
fun String.toAsciiDigits(): String = map {
    when (it) {
        in '۰'..'۹' -> '0' + (it - '۰')
        in '٠'..'٩' -> '0' + (it - '٠')
        else -> it
    }
}.joinToString("")
