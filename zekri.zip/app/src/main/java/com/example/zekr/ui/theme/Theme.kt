package com.example.zekr.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

val TextLight = Color(0xFF1F2A26)
val TextDark = Color(0xFFF1EFE8)

private fun lightScheme(t: ThemePalette) = lightColorScheme(
    primary = t.p,
    onPrimary = Color.White,
    primaryContainer = t.m,
    onPrimaryContainer = t.d,
    secondaryContainer = t.m,
    onSecondaryContainer = t.d,
    background = t.l,
    onBackground = TextLight,
    surface = Color.White,
    onSurface = TextLight,
    surfaceVariant = t.m,
    onSurfaceVariant = Color(0xFF5F5E5A),
    outline = Color(0x1A000000),
)

private fun darkScheme(t: ThemePalette) = darkColorScheme(
    primary = t.q,
    onPrimary = Color.White,
    primaryContainer = t.x8,
    onPrimaryContainer = t.x1,
    secondaryContainer = t.x8,
    onSecondaryContainer = t.x1,
    background = t.x9,
    onBackground = TextDark,
    surface = lerp(t.x9, Color.White, 0.08f),
    onSurface = TextDark,
    surfaceVariant = t.x8,
    onSurfaceVariant = Color(0xB3FFFFFF),
    outline = Color(0x24FFFFFF),
)

/** تم برنامه؛ رنگ و حالت تیره از تنظیمات کاربر می‌آیند. */
@Composable
fun ZekrTheme(
    palette: ThemePalette = BuiltInThemes.green,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) darkScheme(palette) else lightScheme(palette),
        content = content,
    )
}
