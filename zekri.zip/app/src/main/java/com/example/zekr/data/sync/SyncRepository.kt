package com.example.zekr.data.sync

import androidx.room.withTransaction
import com.example.zekr.data.local.AppDatabase
import com.example.zekr.data.local.OutboxEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

enum class PushResult { Done, NotLoggedIn, Retry }

/**
 * ارسال صف تغییرات به سرور. فقط وقتی کاربر وارد شده باشد کار می‌کند؛
 * در غیر این صورت داده‌ها امن روی گوشی می‌مانند تا بعد از ورود ارسال شوند.
 */
class SyncRepository(
    private val db: AppDatabase,
    private val auth: AuthStore,
    private val api: ApiClient,
) {
    private val outbox = db.outboxDao()
    private val sessions = db.sessionDao()

    val pendingCount: Flow<Int> = outbox.observeCount()
    val isLoggedIn: StateFlow<Boolean> = auth.isLoggedIn

    suspend fun push(): PushResult {
        while (true) {
            val token = auth.accessToken() ?: return PushResult.NotLoggedIn
            val batch = outbox.pending(BATCH_SIZE)
            if (batch.isEmpty()) return PushResult.Done

            val response = try {
                api.push(token, batch)
            } catch (e: IOException) {
                outbox.bumpAttempts(batch.map { it.id }, e.message)
                return PushResult.Retry
            } catch (e: JSONException) {
                outbox.bumpAttempts(batch.map { it.id }, "bad response")
                return PushResult.Retry
            }

            if (response.code == 401) {
                // توکن منقضی یا نامعتبر است؛ کاربر باید دوباره وارد شود
                auth.clear()
                return PushResult.NotLoggedIn
            }
            if (response.code !in 200..299) {
                outbox.bumpAttempts(batch.map { it.id }, "HTTP ${response.code}")
                return PushResult.Retry
            }

            val finished = mutableListOf<OutboxEntry>()
            val failed = mutableListOf<String>()
            batch.forEach { entry ->
                when (response.results[entry.id]) {
                    "ok", "duplicate", "rejected" -> finished += entry // rejected: داده نامعتبر، دوباره تلاش نمی‌شود
                    else -> failed += entry.id
                }
            }
            db.withTransaction {
                val sessionIds = finished.filter { it.type == "session" }.mapNotNull { payloadId(it) }
                if (sessionIds.isNotEmpty()) sessions.markSynced(sessionIds)
                if (finished.isNotEmpty()) outbox.delete(finished.map { it.id })
                if (failed.isNotEmpty()) outbox.bumpAttempts(failed, "not acknowledged")
            }
            if (failed.isNotEmpty()) return PushResult.Retry
        }
    }

    private fun payloadId(e: OutboxEntry): String? =
        try { JSONObject(e.payloadJson).getString("id") } catch (_: JSONException) { null }

    private companion object {
        const val BATCH_SIZE = 50
    }
}
