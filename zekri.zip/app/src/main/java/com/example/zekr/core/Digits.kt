package com.example.zekr.core

/**
 * تبدیل ارقام به رقم‌های هر زبان.
 * فارسی و اردو: ۰۱۲۳  |  عربی: ٠١٢٣  |  انگلیسی: 0123
 */
fun String.toLocalizedDigits(lang: String): String = when (lang) {
    "fa", "ur" -> map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")
    "ar" -> map { if (it in '0'..'9') '٠' + (it - '0') else it }.joinToString("")
    else -> this
}

fun Int.toLocalizedDigits(lang: String): String = toString().toLocalizedDigits(lang)

/** عدد با جداکننده هزارگان و ارقام همان زبان. مثلاً 12500 ← ۱۲٬۵۰۰ */
fun Int.formatLocalized(lang: String): String {
    val grouped = String.format(java.util.Locale.ROOT, "%,d", this)
        .replace(',', if (lang == "fa" || lang == "ar" || lang == "ur") '٬' else ',')
    return grouped.toLocalizedDigits(lang)
}
