package com.example.zekr.feature.stats

import com.example.zekr.core.toDate
import com.example.zekr.data.local.SessionHistory
import java.time.LocalDate
import java.time.ZoneId

/** یک ستون نمودار. در حالت هفتگی [date] پر است و در حالت ماهانه فقط [index] (شماره هفته). */
data class Bar(val date: LocalDate?, val index: Int, val total: Int)

data class TopItem(val dhikrId: Long, val total: Int)

data class StatsResult(
    val streak: Int,
    val record: Int,
    val total: Int,
    val average: Int,
    val bars: List<Bar>,
    val top: List<TopItem>,
    val hasData: Boolean,
)

/** محاسبه آمار از روی تاریخچه جلسه‌ها. کاملاً مستقل از دیتابیس و رابط کاربری. */
object StatsCalculator {

    fun compute(sessions: List<SessionHistory>, monthly: Boolean, today: LocalDate, zone: ZoneId): StatsResult {
        val perDay = sessions
            .groupBy { toDate(it.endedAt, zone) }
            .mapValues { entry -> entry.value.sumOf { it.count } }

        val span = if (monthly) 28 else 7
        val start = today.minusDays((span - 1).toLong())

        val bars = if (!monthly) {
            (0 until 7).map { i ->
                val d = start.plusDays(i.toLong())
                Bar(d, i, perDay[d] ?: 0)
            }
        } else {
            (0 until 4).map { w ->
                val sum = (0 until 7).sumOf { k -> perDay[start.plusDays((w * 7 + k).toLong())] ?: 0 }
                Bar(null, w, sum)
            }
        }
        val total = bars.sumOf { it.total }

        val top = sessions
            .filter { val d = toDate(it.endedAt, zone); !d.isBefore(start) && !d.isAfter(today) }
            .groupBy { it.dhikrId }
            .map { TopItem(it.key, it.value.sumOf { s -> s.count }) }
            .sortedByDescending { it.total }
            .take(3)

        val days = perDay.keys
        return StatsResult(
            streak = currentStreak(days, today),
            record = longestRun(days),
            total = total,
            average = total / span,
            bars = bars,
            top = top,
            hasData = sessions.isNotEmpty(),
        )
    }

    /** روزهای پشت‌سرهم تا امروز. اگر امروز هنوز چیزی نگفته باشید، از دیروز حساب می‌شود (رشته هنوز نشکسته). */
    fun currentStreak(days: Set<LocalDate>, today: LocalDate): Int {
        var d = if (today in days) today else today.minusDays(1)
        var n = 0
        while (d in days) {
            n++
            d = d.minusDays(1)
        }
        return n
    }

    fun longestRun(days: Set<LocalDate>): Int {
        if (days.isEmpty()) return 0
        val sorted = days.sorted()
        var best = 1
        var run = 1
        for (i in 1 until sorted.size) {
            run = if (sorted[i - 1].plusDays(1) == sorted[i]) run + 1 else 1
            if (run > best) best = run
        }
        return best
    }
}
