package com.example.zekr.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import java.util.UUID

/** یک ذکر (آماده یا دلخواه کاربر). */
@Entity(tableName = "dhikr")
data class DhikrEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** کلید ذکرهای آماده (مثل "salawat")؛ برای ذکر دلخواه null است. */
    val builtinKey: String? = null,
    val arabicText: String,
    /** نام دلخواه؛ برای ذکرهای آماده از strings.xml خوانده می‌شود. */
    val title: String? = null,
    /** salawat | istighfar | tasbih | custom */
    val category: String,
    val suggestedCount: Int,
    val isCustom: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
)

/** معنی ذکر به یک زبان. */
@Entity(
    tableName = "dhikr_translation",
    primaryKeys = ["dhikrId", "lang"],
    foreignKeys = [ForeignKey(
        entity = DhikrEntity::class,
        parentColumns = ["id"],
        childColumns = ["dhikrId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("dhikrId")],
)
data class DhikrTranslation(
    val dhikrId: Long,
    val lang: String,
    val meaning: String,
)

data class DhikrWithTranslations(
    @Embedded val dhikr: DhikrEntity,
    @Relation(parentColumn = "id", entityColumn = "dhikrId")
    val translations: List<DhikrTranslation>,
) {
    /** معنی به زبان خواسته‌شده؛ اگر نبود، از زبان‌های دیگر. */
    fun meaning(lang: String): String? =
        translations.firstOrNull { it.lang == lang }?.meaning
            ?: translations.firstOrNull { it.lang == "en" }?.meaning
            ?: translations.firstOrNull { it.lang == "fa" }?.meaning
            ?: translations.firstOrNull()?.meaning
}

/** وضعیت زنده شمارنده (همیشه فقط یک ردیف با id=1). */
@Entity(tableName = "counter_state")
data class CounterState(
    @PrimaryKey val id: Int = 1,
    val dhikrId: Long,
    val count: Int = 0,
    val goal: Int = 100,
    val startedAt: Long? = null,
    val khatmId: Long? = null,
    val intention: String? = null,
    val resetLocked: Boolean = true,
)

/** پشته برگرداندن (Undo): آخرین ۵۰ مرحله. */
@Entity(tableName = "counter_undo")
data class CounterUndo(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val previousCount: Int,
    val createdAt: Long = System.currentTimeMillis(),
)

/** تاریخچه هر جلسه ذکر. */
@Entity(tableName = "session_history", indices = [Index("endedAt")])
data class SessionHistory(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val dhikrId: Long,
    val khatmId: Long? = null,
    val count: Int,
    val goal: Int,
    val durationSec: Int,
    val startedAt: Long,
    val endedAt: Long,
    /** local | pending | synced */
    val syncState: String = "local",
)

/** ختم (آنلاین یا شخصی). */
@Entity(tableName = "khatm")
data class KhatmEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val serverId: String? = null,
    val title: String,
    val dhikrId: Long,
    val totalCount: Long,
    val doneCount: Long = 0,
    val myCount: Long = 0,
    /** online | personal */
    val type: String,
    val isOwner: Boolean = true,
    val deadlineAt: Long? = null,
    val intention: String? = null,
    val inviteCode: String? = null,
    /** active | completed | closed */
    val status: String = "active",
    val version: Int = 1,
    val syncState: String = "local",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

/** هر بار ثبت مشارکت من در یک ختم. */
@Entity(
    tableName = "khatm_contribution",
    foreignKeys = [ForeignKey(
        entity = KhatmEntity::class,
        parentColumns = ["id"],
        childColumns = ["khatmId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("khatmId")],
)
data class KhatmContribution(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val khatmId: Long,
    val amount: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val syncState: String = "local",
)

/**
 * صف ارسال به سرور. هر تغییر مهم (مثلاً پایان یک جلسه) اینجا ثبت می‌شود و
 * وقتی کاربر وارد شده و اینترنت وصل است، به سرور فرستاده و از صف حذف می‌شود.
 */
@Entity(tableName = "outbox", indices = [Index("createdAt")])
data class OutboxEntry(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    /** مثلاً "session" */
    val type: String,
    val payloadJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val attempts: Int = 0,
    val lastError: String? = null,
)

/**
 * تم دانلودشده از سایت. فقط رنگ‌ها ذخیره می‌شوند (به‌صورت ARGB)؛
 * هیچ کدی از تم اجرا نمی‌شود.
 */
@Entity(tableName = "custom_theme")
data class ThemeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val primary: Int,
    val primaryDark: Int,
    val background: Int,
    val container: Int,
    val onContainer: Int,
    val containerDark: Int,
    val onContainerDark: Int,
    val backgroundDark: Int,
    val sourceUrl: String? = null,
    val addedAt: Long = System.currentTimeMillis(),
)
