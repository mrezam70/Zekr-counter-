package com.example.zekr.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        DhikrEntity::class,
        DhikrTranslation::class,
        CounterState::class,
        CounterUndo::class,
        SessionHistory::class,
        KhatmEntity::class,
        KhatmContribution::class,
        OutboxEntry::class,
        ThemeEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dhikrDao(): DhikrDao
    abstract fun counterDao(): CounterDao
    abstract fun sessionDao(): SessionDao
    abstract fun khatmDao(): KhatmDao
    abstract fun outboxDao(): OutboxDao
    abstract fun themeDao(): ThemeDao
}
