package com.example.zekr.data.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import com.example.zekr.data.local.ThemeEntity
import com.example.zekr.ui.theme.BuiltInThemes
import com.example.zekr.ui.theme.ThemePalette

fun ThemeEntity.toPalette() = ThemePalette(
    id = id,
    p = Color(primary),
    q = Color(primaryDark),
    l = Color(background),
    m = Color(container),
    d = Color(onContainer),
    x8 = Color(containerDark),
    x1 = Color(onContainerDark),
    x9 = Color(backgroundDark),
)

/** تم انتخاب‌شده را پیدا می‌کند؛ اگر حذف شده باشد، سبز اسلامی. */
fun resolvePalette(id: String, custom: List<ThemeEntity>): ThemePalette =
    BuiltInThemes.byId(id)
        ?: custom.firstOrNull { it.id == id }?.toPalette()
        ?: BuiltInThemes.green

@Composable
fun themeDisplayName(id: String, custom: List<ThemeEntity>): String {
    BuiltInThemes.nameRes(id)?.let { return stringResource(it) }
    return custom.firstOrNull { it.id == id }?.name
        ?: stringResource(BuiltInThemes.nameRes("green")!!)
}
