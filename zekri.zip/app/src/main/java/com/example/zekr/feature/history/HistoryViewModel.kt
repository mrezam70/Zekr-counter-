package com.example.zekr.feature.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.zekr.data.local.DhikrWithTranslations
import com.example.zekr.data.local.SessionHistory
import com.example.zekr.data.repo.DhikrRepository
import com.example.zekr.data.repo.SessionRepository
import com.example.zekr.data.sync.SyncRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HistoryUi(
    val sessions: List<SessionHistory> = emptyList(),
    val dhikr: Map<Long, DhikrWithTranslations> = emptyMap(),
    val pending: Int = 0,
    val loggedIn: Boolean = false,
)

class HistoryViewModel(
    sessions: SessionRepository,
    dhikrRepo: DhikrRepository,
    sync: SyncRepository,
) : ViewModel() {

    val ui: StateFlow<HistoryUi> = combine(
        sessions.observeAll(),
        dhikrRepo.observeAll(),
        sync.pendingCount,
        sync.isLoggedIn,
    ) { list, dhikr, pending, loggedIn ->
        HistoryUi(list, dhikr.associateBy { it.dhikr.id }, pending, loggedIn)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryUi())

    companion object {
        fun factory(sessions: SessionRepository, dhikrRepo: DhikrRepository, sync: SyncRepository) =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    HistoryViewModel(sessions, dhikrRepo, sync) as T
            }
    }
}
