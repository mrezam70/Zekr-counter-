package com.example.zekr.data

import android.content.Context
import androidx.room.Room
import com.example.zekr.BuildConfig
import com.example.zekr.data.local.AppDatabase
import com.example.zekr.data.repo.CounterRepository
import com.example.zekr.data.repo.DhikrRepository
import com.example.zekr.data.repo.SessionRepository
import com.example.zekr.data.settings.SettingsRepository
import com.example.zekr.data.sync.ApiClient
import com.example.zekr.data.sync.AuthStore
import com.example.zekr.data.sync.SyncRepository
import com.example.zekr.data.sync.SyncScheduler
import com.example.zekr.data.theme.ThemeRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** ساخت و نگهداری اشیای مشترک برنامه (دیتابیس، مخزن‌ها و همگام‌سازی). */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val db: AppDatabase = Room.databaseBuilder(appContext, AppDatabase::class.java, "zekr.db")
        // فقط برای دوران توسعه. قبل از انتشار حذف و با Migration واقعی جایگزین می‌شود.
        .fallbackToDestructiveMigration()
        .build()

    private val enqueueSync = { SyncScheduler.enqueueNow(appContext) }

    val authStore = AuthStore(appContext)
    val syncRepo = SyncRepository(db, authStore, ApiClient(BuildConfig.SERVER_URL))

    val settingsRepo = SettingsRepository(appContext, appScope, db.outboxDao(), db.themeDao(), enqueueSync)
    val themeRepo = ThemeRepository(
        dao = db.themeDao(),
        catalogUrl = BuildConfig.THEMES_CATALOG_URL,
        onChanged = { settingsRepo.enqueueSync() },
    )

    val dhikrRepo = DhikrRepository(db.dhikrDao())
    val sessionRepo = SessionRepository(db.sessionDao())
    val counterRepo = CounterRepository(db, onOutboxChanged = enqueueSync)

    /** وقتی صفحه شمارش جلوی کاربر است true می‌شود (برای شمارش با دکمه‌های ولوم). */
    @Volatile
    var counterScreenActive: Boolean = false
}
