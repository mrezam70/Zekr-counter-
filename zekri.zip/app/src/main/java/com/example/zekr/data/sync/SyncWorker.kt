package com.example.zekr.data.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.zekr.ZekrApp

/** کار پس‌زمینه: صف تغییرات را به سرور می‌فرستد. */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as ZekrApp).container
        return when (container.syncRepo.push()) {
            PushResult.Retry -> Result.retry()
            PushResult.Done, PushResult.NotLoggedIn -> Result.success()
        }
    }
}
