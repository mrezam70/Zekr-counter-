package com.example.zekr.data.local

/** ذکرهای آماده که بار اول اجرا وارد دیتابیس می‌شوند. */
object SeedData {
    class Item(
        val key: String,
        val arabic: String,
        val category: String,
        val suggested: Int,
        val meanings: Map<String, String>,
    )

    val items = listOf(
        Item(
            "salawat", "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّدٍ", "salawat", 100,
            mapOf(
                "fa" to "خدایا، بر محمد و خاندان محمد درود بفرست",
                "ar" to "الصلاة على النبي وآله",
                "en" to "O Allah, send blessings upon Muhammad and his family",
                "ur" to "اے اللہ، محمد اور آلِ محمد پر درود بھیج",
                "zh" to "真主啊，求你祝福穆罕默德及其家属",
                "ja" to "神よ、ムハンマドとその家族に祝福を",
                "ko" to "하나님, 무함마드와 그 가족에게 축복을 내리소서",
            ),
        ),
        Item(
            "istighfar", "أَسْتَغْفِرُ اللَّهَ رَبِّي وَأَتُوبُ إِلَيْهِ", "istighfar", 100,
            mapOf(
                "fa" to "از پروردگارم آمرزش می‌خواهم و به سوی او بازمی‌گردم",
                "ar" to "طلب المغفرة والتوبة",
                "en" to "I seek forgiveness from my Lord and turn to Him",
                "ur" to "میں اپنے رب سے بخشش مانگتا ہوں اور اسی کی طرف رجوع کرتا ہوں",
                "zh" to "我向我的主求饶恕，并向祂悔罪",
                "ja" to "私は主に赦しを請い、主に立ち返ります",
                "ko" to "저는 주님께 용서를 구하고 그분께 돌아갑니다",
            ),
        ),
        Item(
            "subhan", "سُبْحَانَ اللَّهِ", "tasbih", 33,
            mapOf(
                "fa" to "خدا پاک و منزه است",
                "ar" to "تنزيه الله عن كل نقص",
                "en" to "Glory be to God",
                "ur" to "اللہ پاک ہے",
                "zh" to "赞颂真主超绝",
                "ja" to "神に栄光あれ",
                "ko" to "하나님께 영광을",
            ),
        ),
        Item(
            "tahlil", "لَا إِلَهَ إِلَّا اللَّهُ", "tasbih", 100,
            mapOf(
                "fa" to "هیچ معبودی جز خدا نیست",
                "ar" to "كلمة التوحيد",
                "en" to "There is no god but God",
                "ur" to "اللہ کے سوا کوئی معبود نہیں",
                "zh" to "万物非主，唯有真主",
                "ja" to "神のほかに神はなし",
                "ko" to "하나님 외에 신은 없다",
            ),
        ),
    )
}
