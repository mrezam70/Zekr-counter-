package com.example.zekr.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.zekr.R
import com.example.zekr.ZekrApp
import com.example.zekr.core.LanguageManager
import com.example.zekr.core.openContactEmail
import com.example.zekr.feature.counter.CounterScreen
import com.example.zekr.feature.history.HistoryScreen
import com.example.zekr.feature.library.DhikrDetailScreen
import com.example.zekr.feature.library.LibraryScreen
import com.example.zekr.feature.settings.SettingsScreen
import com.example.zekr.feature.stats.StatsScreen
import com.example.zekr.feature.themes.ThemesScreen
import kotlinx.coroutines.launch

/** مقصدهای برنامه. سه مورد منو از منوی همبرگری باز می‌شوند. */
private enum class Dest(val route: String, @StringRes val title: Int, val icon: ImageVector) {
    Count("count", R.string.nav_count, Icons.Filled.TouchApp),
    Library("library", R.string.nav_dhikr, Icons.Filled.MenuBook),
    Stats("stats", R.string.nav_stats, Icons.Filled.BarChart),
    Settings("settings", R.string.nav_settings, Icons.Filled.Settings),
    Themes("themes", R.string.themes_title, Icons.Filled.Palette),
    Khatm("khatm", R.string.menu_khatm, Icons.Filled.Groups),
    History("history", R.string.menu_history, Icons.Filled.History),
    Resume("resume", R.string.menu_resume, Icons.Filled.PlayArrow),
}

private val implementedDests = setOf(
    Dest.Count, Dest.Library, Dest.Stats, Dest.Settings, Dest.Themes, Dest.History,
)
private val bottomTabs = listOf(Dest.Count, Dest.Library, Dest.Stats, Dest.Settings)
private val menuItems = listOf(Dest.Khatm, Dest.History, Dest.Resume)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZekrRoot() {
    val nav = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val isDetail = route?.startsWith("dhikr/") == true
    val isSubScreen = isDetail || route == Dest.Themes.route
    val currentDest = Dest.entries.firstOrNull { it.route == route } ?: Dest.Library
    val ctx = LocalContext.current
    val container = (ctx.applicationContext as ZekrApp).container
    val repo = container.dhikrRepo
    val counters = container.counterRepo

    fun go(dest: Dest) {
        nav.navigate(dest.route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 24.dp),
                    )
                    menuItems.forEach { d ->
                        NavigationDrawerItem(
                            label = { Text(stringResource(d.title)) },
                            icon = { Icon(d.icon, contentDescription = null) },
                            selected = route == d.route,
                            onClick = {
                                scope.launch { drawerState.close() }
                                go(d)
                            },
                            modifier = Modifier.padding(horizontal = 12.dp),
                        )
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                    Row(
                        modifier = Modifier.padding(horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Language, contentDescription = null)
                        Text(
                            text = stringResource(R.string.menu_language),
                            modifier = Modifier.padding(start = 12.dp),
                        )
                    }
                    LanguageChips()
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                    NavigationDrawerItem(
                        label = { Text(stringResource(R.string.menu_contact)) },
                        icon = { Icon(Icons.Filled.Email, contentDescription = null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            openContactEmail(ctx)
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    )
                }
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            stringResource(
                                if (isDetail) R.string.dhikr_details else currentDest.title,
                            ),
                        )
                    },
                    navigationIcon = {
                        if (isSubScreen) {
                            IconButton(onClick = { nav.popBackStack() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                            }
                        } else {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Filled.Menu, contentDescription = stringResource(R.string.menu_open))
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = MaterialTheme.colorScheme.onPrimary,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                )
            },
            bottomBar = {
                NavigationBar {
                    bottomTabs.forEach { d ->
                        NavigationBarItem(
                            selected = route == d.route ||
                                (d == Dest.Library && isDetail) ||
                                (d == Dest.Settings && route == Dest.Themes.route),
                            onClick = { go(d) },
                            icon = { Icon(d.icon, contentDescription = null) },
                            label = { Text(stringResource(d.title)) },
                        )
                    }
                }
            },
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Dest.Count.route,
                modifier = Modifier.padding(padding),
            ) {
                composable(Dest.Count.route) {
                    CounterScreen(counters = counters, dhikrRepo = repo, settingsRepo = container.settingsRepo)
                }
                composable(Dest.Stats.route) {
                    StatsScreen(sessions = container.sessionRepo, dhikrRepo = repo)
                }
                composable(Dest.History.route) {
                    HistoryScreen(sessions = container.sessionRepo, dhikrRepo = repo, sync = container.syncRepo)
                }
                composable(Dest.Settings.route) {
                    SettingsScreen(
                        settingsRepo = container.settingsRepo,
                        themeRepo = container.themeRepo,
                        onOpenThemes = { nav.navigate(Dest.Themes.route) },
                    )
                }
                composable(Dest.Themes.route) {
                    ThemesScreen(settingsRepo = container.settingsRepo, themeRepo = container.themeRepo)
                }
                composable(Dest.Library.route) {
                    LibraryScreen(repo = repo, onOpen = { id -> nav.navigate("dhikr/$id") })
                }
                composable(
                    route = "dhikr/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.LongType }),
                ) { be ->
                    DhikrDetailScreen(
                        repo = repo,
                        id = be.arguments?.getLong("id") ?: 0L,
                        onBack = { nav.popBackStack() },
                        onStart = { dhikrId, goal, intention ->
                            scope.launch {
                                counters.start(dhikrId, goal, intention)
                                nav.navigate(Dest.Count.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { inclusive = false }
                                    launchSingleTop = true
                                }
                            }
                        },
                    )
                }
                Dest.entries.filter { it !in implementedDests }.forEach { d ->
                    composable(d.route) { SoonScreen() }
                }
            }
        }
    }
}

@Composable
private fun LanguageChips() {
    val current = LocalConfiguration.current.locales[0].language
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        LanguageManager.languages.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (code, name) ->
                    FilterChip(
                        selected = current == code,
                        onClick = { LanguageManager.set(code) },
                        label = { Text(name) },
                    )
                }
            }
        }
    }
}

/** صفحه موقت برای صفحه‌هایی که در مراحل بعد ساخته می‌شوند (ختم، ادامه و یادآور). */
@Composable
private fun SoonScreen() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp),
        ) {
            Text(
                text = stringResource(R.string.soon_title),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = stringResource(R.string.soon_body),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    }
}
