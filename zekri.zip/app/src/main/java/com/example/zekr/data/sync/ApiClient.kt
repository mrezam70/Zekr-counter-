package com.example.zekr.data.sync

import com.example.zekr.data.local.OutboxEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * ارتباط با سرور. قرارداد کامل در docs/SYNC_API.md است.
 *
 * POST {SERVER_URL}v1/sync/push
 *   درخواست: {"ops":[{"id":"...","type":"session","payload":{...}}]}
 *   پاسخ:    {"results":[{"id":"...","status":"ok|duplicate|rejected"}]}
 */
class ApiClient(
    private val baseUrl: String,
    private val http: OkHttpClient = OkHttpClient(),
) {
    class PushResponse(val code: Int, val results: Map<String, String>)

    suspend fun push(token: String, entries: List<OutboxEntry>): PushResponse = withContext(Dispatchers.IO) {
        val ops = JSONArray()
        entries.forEach {
            ops.put(
                JSONObject()
                    .put("id", it.id)
                    .put("type", it.type)
                    .put("payload", JSONObject(it.payloadJson)),
            )
        }
        val body = JSONObject().put("ops", ops).toString()
            .toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(baseUrl + "v1/sync/push")
            .header("Authorization", "Bearer $token")
            .post(body)
            .build()

        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val results = mutableMapOf<String, String>()
            if (response.isSuccessful) {
                val arr = JSONObject(text).optJSONArray("results")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        results[o.getString("id")] = o.optString("status")
                    }
                }
            }
            PushResponse(response.code, results)
        }
    }
}
