package com.example.zekr.feature.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.zekr.R
import com.example.zekr.core.normalizeArabic
import com.example.zekr.core.toLocalizedDigits
import com.example.zekr.data.repo.DhikrRepository

private val categories = listOf(
    "all" to R.string.cat_all,
    "salawat" to R.string.cat_salawat,
    "istighfar" to R.string.cat_istighfar,
    "tasbih" to R.string.cat_tasbih,
    "custom" to R.string.cat_custom,
)

@Composable
fun LibraryScreen(repo: DhikrRepository, onOpen: (Long) -> Unit) {
    val vm: DhikrViewModel = viewModel(factory = DhikrViewModel.factory(repo))
    val items by vm.items.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language

    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("all") }
    var showAdd by remember { mutableStateOf(false) }

    val q = query.normalizeArabic().trim()
    val filtered = items.filter { item ->
        val d = item.dhikr
        val catOk = when (category) {
            "all" -> true
            "custom" -> d.isCustom
            else -> d.category == category
        }
        val textOk = q.isEmpty() ||
            (d.arabicText + " " + item.nameOf(ctx) + " " + (item.meaning(lang) ?: "")).normalizeArabic().contains(q)
        catOk && textOk
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(stringResource(R.string.search_dhikr)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp),
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(categories) { (key, label) ->
                    FilterChip(
                        selected = category == key,
                        onClick = { category = key },
                        label = { Text(stringResource(label)) },
                    )
                }
            }
            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.TopCenter) {
                    Text(
                        text = stringResource(R.string.empty_search),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(filtered, key = { it.dhikr.id }) { item ->
                        Card(
                            onClick = { onOpen(item.dhikr.id) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(40.dp),
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Filled.MenuBook,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                    Text(
                                        text = item.dhikr.arabicText,
                                        style = MaterialTheme.typography.titleMedium.copy(textDirection = TextDirection.Rtl),
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                    Text(
                                        text = item.nameOf(ctx) + " · " +
                                            stringResource(
                                                R.string.suggested_count,
                                                item.dhikr.suggestedCount.toLocalizedDigits(lang),
                                            ),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Icon(
                                    Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { showAdd = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        ) {
            Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.add_dhikr))
        }
    }

    if (showAdd) {
        DhikrEditDialog(
            initial = null,
            lang = lang,
            onDismiss = { showAdd = false },
            onSave = { arabic, title, suggested, meaning ->
                vm.add(arabic, title, suggested, lang, meaning)
                showAdd = false
            },
        )
    }
}
