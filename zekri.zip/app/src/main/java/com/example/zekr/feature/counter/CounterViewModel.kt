package com.example.zekr.feature.counter

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.zekr.data.local.DhikrWithTranslations
import com.example.zekr.data.repo.CounterRepository
import com.example.zekr.data.repo.DhikrRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CounterUi(
    val ready: Boolean = false,
    val count: Int = 0,
    val goal: Int = 100,
    val dhikr: DhikrWithTranslations? = null,
    val intention: String? = null,
    val locked: Boolean = true,
    val undoCount: Int = 0,
    val allDhikr: List<DhikrWithTranslations> = emptyList(),
)

class CounterViewModel(
    private val counters: CounterRepository,
    dhikrRepo: DhikrRepository,
) : ViewModel() {

    val ui: StateFlow<CounterUi> = combine(
        counters.observeState(),
        counters.observeUndoCount(),
        dhikrRepo.observeAll(),
    ) { s, undo, all ->
        CounterUi(
            ready = s != null,
            count = s?.count ?: 0,
            goal = s?.goal ?: 100,
            dhikr = all.firstOrNull { it.dhikr.id == s?.dhikrId },
            intention = s?.intention,
            locked = s?.resetLocked ?: true,
            undoCount = undo,
            allDhikr = all,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CounterUi())

    fun increment() { viewModelScope.launch { counters.increment() } }
    fun undo() { viewModelScope.launch { counters.undo() } }
    fun setCount(n: Int) { viewModelScope.launch { counters.setCount(n) } }
    fun reset() { viewModelScope.launch { counters.reset() } }
    fun setLocked(locked: Boolean) { viewModelScope.launch { counters.setLocked(locked) } }
    fun endSession() { viewModelScope.launch { counters.endSession() } }

    /** انتخاب ذکر دیگر از نوار بالای صفحه شمارش. */
    fun selectDhikr(item: DhikrWithTranslations) {
        viewModelScope.launch { counters.start(item.dhikr.id, item.dhikr.suggestedCount, null) }
    }

    companion object {
        fun factory(counters: CounterRepository, dhikrRepo: DhikrRepository) =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    CounterViewModel(counters, dhikrRepo) as T
            }
    }
}
