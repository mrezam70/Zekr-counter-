package com.example.zekr

import android.app.Application
import com.example.zekr.data.AppContainer
import com.example.zekr.data.sync.SyncScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ZekrApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        SyncScheduler.schedulePeriodic(this)
        CoroutineScope(Dispatchers.IO).launch {
            container.dhikrRepo.seedIfEmpty()
            container.counterRepo.ensureState()
        }
    }
}
