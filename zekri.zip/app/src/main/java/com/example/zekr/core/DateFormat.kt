package com.example.zekr.core

import android.content.Context
import com.example.zekr.R
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

fun toDate(millis: Long, zone: ZoneId): LocalDate =
    Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()

/** امروز، دیروز، یا تاریخ (فعلاً میلادی؛ تقویم شمسی در نسخه‌های بعد اضافه می‌شود). */
fun dayLabel(ctx: Context, date: LocalDate, today: LocalDate, lang: String): String = when (date) {
    today -> ctx.getString(R.string.day_today)
    today.minusDays(1) -> ctx.getString(R.string.day_yesterday)
    else -> String.format(Locale.ROOT, "%04d/%02d/%02d", date.year, date.monthValue, date.dayOfMonth)
        .toLocalizedDigits(lang)
}

fun timeLabel(millis: Long, zone: ZoneId, lang: String): String {
    val t = Instant.ofEpochMilli(millis).atZone(zone).toLocalTime()
    return String.format(Locale.ROOT, "%02d:%02d", t.hour, t.minute).toLocalizedDigits(lang)
}

fun durationLabel(ctx: Context, seconds: Int, lang: String): String {
    val text = String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60).toLocalizedDigits(lang)
    return text + " " + ctx.getString(R.string.unit_min)
}
