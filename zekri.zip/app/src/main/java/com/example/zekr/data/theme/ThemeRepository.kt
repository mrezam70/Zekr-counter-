package com.example.zekr.data.theme

import com.example.zekr.data.local.ThemeDao
import com.example.zekr.data.local.ThemeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class ImportResult {
    object Success : ImportResult()
    object BadUrl : ImportResult()
    object Network : ImportResult()
    object Limit : ImportResult()
    data class Invalid(val reason: String) : ImportResult()
    data class Contrast(val reason: String) : ImportResult()
}

data class CatalogItem(val id: String, val name: String, val url: String)

/**
 * دانلود و ذخیره تم‌ها. فقط از آدرس https و با حجم محدود دانلود می‌شود،
 * و فقط رنگ‌ها خوانده می‌شوند.
 */
class ThemeRepository(
    private val dao: ThemeDao,
    private val catalogUrl: String,
    private val onChanged: suspend () -> Unit,
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build(),
) {
    val custom: Flow<List<ThemeEntity>> = dao.observeAll()

    suspend fun importFromUrl(rawUrl: String, lang: String): ImportResult {
        val url = rawUrl.trim().toHttpUrlOrNull()
        if (url == null || !url.isHttps) return ImportResult.BadUrl

        val body = download(url.toString())
        if (body.failed) return ImportResult.Network
        if (body.tooLarge) return ImportResult.Invalid("size")

        return when (val parsed = ThemeParser.parse(body.text.orEmpty(), lang, url.toString())) {
            is ParseResult.Invalid -> ImportResult.Invalid(parsed.reason)
            is ParseResult.Contrast -> ImportResult.Contrast(parsed.reason)
            is ParseResult.Ok -> {
                val isUpdate = dao.exists(parsed.theme.id) > 0
                if (!isUpdate && dao.count() >= MAX_THEMES) return ImportResult.Limit
                dao.upsert(parsed.theme)
                onChanged()
                ImportResult.Success
            }
        }
    }

    /** فهرست تم‌های آنلاین. اگر دریافت نشد null برمی‌گرداند. */
    suspend fun fetchCatalog(): List<CatalogItem>? {
        val body = download(catalogUrl)
        if (body.failed || body.tooLarge) return null
        return try {
            val arr = JSONObject(body.text.orEmpty()).optJSONArray("themes") ?: return emptyList()
            buildList {
                for (i in 0 until minOf(arr.length(), MAX_CATALOG)) {
                    val o = arr.getJSONObject(i)
                    val url = o.optString("url")
                    val name = o.optString("name").filter { !it.isISOControl() }.trim()
                    if (name.isNotEmpty() && url.toHttpUrlOrNull()?.isHttps == true) {
                        add(CatalogItem(o.optString("id"), name.take(30), url))
                    }
                }
            }
        } catch (e: JSONException) {
            null
        }
    }

    suspend fun delete(id: String) {
        dao.delete(id)
        onChanged()
    }

    private class Download(val text: String?, val failed: Boolean, val tooLarge: Boolean)

    private suspend fun download(url: String): Download = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(url).header("Accept", "application/json").build()
            http.newCall(request).execute().use { response ->
                // بعد از تغییر مسیر (redirect) هم باید https بماند
                if (!response.isSuccessful || !response.request.url.isHttps) {
                    return@use Download(null, failed = true, tooLarge = false)
                }
                val source = response.body?.source()
                    ?: return@use Download(null, failed = true, tooLarge = false)
                val buffer = okio.Buffer()
                var total = 0L
                while (true) {
                    val n = source.read(buffer, 8192)
                    if (n == -1L) break
                    total += n
                    if (total > MAX_BYTES) return@use Download(null, failed = false, tooLarge = true)
                }
                Download(buffer.readUtf8(), failed = false, tooLarge = false)
            }
        } catch (e: IOException) {
            Download(null, failed = true, tooLarge = false)
        }
    }

    companion object {
        const val MAX_THEMES = 20
        private const val MAX_CATALOG = 50
        private const val MAX_BYTES = 16 * 1024L
    }
}
