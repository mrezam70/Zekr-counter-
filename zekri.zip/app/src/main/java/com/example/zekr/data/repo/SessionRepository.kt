package com.example.zekr.data.repo

import com.example.zekr.data.local.SessionDao
import com.example.zekr.data.local.SessionHistory
import kotlinx.coroutines.flow.Flow

class SessionRepository(private val dao: SessionDao) {
    fun observeAll(): Flow<List<SessionHistory>> = dao.observeAll()
}
