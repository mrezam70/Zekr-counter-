package com.example.zekr.feature.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.zekr.data.local.DhikrWithTranslations
import com.example.zekr.data.repo.DhikrRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DhikrViewModel(private val repo: DhikrRepository) : ViewModel() {

    val items: StateFlow<List<DhikrWithTranslations>> = repo.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(arabic: String, title: String?, suggested: Int, lang: String, meaning: String?) {
        viewModelScope.launch { repo.addCustom(arabic, title, suggested, lang, meaning) }
    }

    fun update(id: Long, arabic: String, title: String?, suggested: Int, lang: String, meaning: String?) {
        viewModelScope.launch { repo.updateCustom(id, arabic, title, suggested, lang, meaning) }
    }

    fun delete(id: Long) {
        viewModelScope.launch { repo.deleteCustom(id) }
    }

    companion object {
        fun factory(repo: DhikrRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = DhikrViewModel(repo) as T
        }
    }
}
