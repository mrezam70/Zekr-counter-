package com.example.zekr.data.sync

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * وضعیت ورود کاربر و توکن‌ها.
 *
 * توجه: فعلاً ساده (SharedPreferences) است. در مرحله ساخت صفحه ورود، توکن‌ها در
 * حافظه امن (Android Keystore) نگهداری خواهند شد.
 */
class AuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("auth", Context.MODE_PRIVATE)
    private val _isLoggedIn = MutableStateFlow(prefs.getString(KEY_ACCESS, null) != null)

    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    fun accessToken(): String? = prefs.getString(KEY_ACCESS, null)

    fun save(access: String, refresh: String?) {
        prefs.edit().putString(KEY_ACCESS, access).putString(KEY_REFRESH, refresh).apply()
        _isLoggedIn.value = true
    }

    fun clear() {
        prefs.edit().clear().apply()
        _isLoggedIn.value = false
    }

    private companion object {
        const val KEY_ACCESS = "access"
        const val KEY_REFRESH = "refresh"
    }
}
