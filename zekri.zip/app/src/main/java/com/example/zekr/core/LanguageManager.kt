package com.example.zekr.core

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/** مدیریت زبان برنامه (مستقل از زبان گوشی). */
object LanguageManager {
    /** کد زبان و نام آن به خود همان زبان */
    val languages = listOf(
        "fa" to "فارسی",
        "ar" to "العربية",
        "en" to "English",
        "ur" to "اردو",
        "zh" to "中文",
        "ja" to "日本語",
        "ko" to "한국어",
    )

    fun set(code: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
    }
}
