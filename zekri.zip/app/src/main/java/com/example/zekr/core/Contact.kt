package com.example.zekr.core

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import com.example.zekr.BuildConfig
import com.example.zekr.R

/**
 * باز کردن برنامه ایمیل با آدرس و موضوع آماده («ارتباط با ما»).
 * فقط نسخه برنامه و نسخه اندروید در متن می‌آید؛ کاربر می‌تواند آن را پاک کند.
 */
fun openContactEmail(ctx: Context) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:")
        putExtra(Intent.EXTRA_EMAIL, arrayOf(BuildConfig.CONTACT_EMAIL))
        putExtra(Intent.EXTRA_SUBJECT, ctx.getString(R.string.contact_subject))
        putExtra(
            Intent.EXTRA_TEXT,
            ctx.getString(R.string.contact_body, BuildConfig.VERSION_NAME, Build.VERSION.RELEASE),
        )
    }
    try {
        ctx.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, ctx.getString(R.string.contact_no_app, BuildConfig.CONTACT_EMAIL), Toast.LENGTH_LONG).show()
    }
}
