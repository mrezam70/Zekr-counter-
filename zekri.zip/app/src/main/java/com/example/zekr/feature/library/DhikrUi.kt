package com.example.zekr.feature.library

import android.content.Context
import com.example.zekr.R
import com.example.zekr.data.local.DhikrWithTranslations

/** نام نمایشی ذکر: نام دلخواه، یا نام ترجمه‌شده ذکر آماده، یا چند کلمه اول متن. */
fun DhikrWithTranslations.nameOf(ctx: Context): String {
    dhikr.title?.takeIf { it.isNotBlank() }?.let { return it }
    val res = when (dhikr.builtinKey) {
        "salawat" -> R.string.dhikr_name_salawat
        "istighfar" -> R.string.dhikr_name_istighfar
        "subhan" -> R.string.dhikr_name_subhan
        "tahlil" -> R.string.dhikr_name_tahlil
        else -> null
    }
    return if (res != null) ctx.getString(res) else dhikr.arabicText.take(24)
}
