package com.example.zekr.feature.library

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.example.zekr.R
import com.example.zekr.core.toAsciiDigits
import com.example.zekr.core.toLocalizedDigits
import com.example.zekr.data.local.DhikrWithTranslations

/** پنجره افزودن یا ویرایش ذکر دلخواه. اگر [initial] خالی باشد، افزودن است. */
@Composable
fun DhikrEditDialog(
    initial: DhikrWithTranslations?,
    lang: String,
    onDismiss: () -> Unit,
    onSave: (arabic: String, title: String?, suggested: Int, meaning: String?) -> Unit,
) {
    var arabic by remember { mutableStateOf(initial?.dhikr?.arabicText.orEmpty()) }
    var title by remember { mutableStateOf(initial?.dhikr?.title.orEmpty()) }
    var meaning by remember { mutableStateOf(initial?.translations?.firstOrNull { it.lang == lang }?.meaning.orEmpty()) }
    var count by remember { mutableStateOf((initial?.dhikr?.suggestedCount ?: 100).toLocalizedDigits(lang)) }
    var tried by remember { mutableStateOf(false) }

    val countValue = count.toAsciiDigits().trim().toIntOrNull()
    val arabicError = tried && arabic.isBlank()
    val countError = tried && (countValue == null || countValue !in 1..1_000_000)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(if (initial == null) R.string.add_dhikr else R.string.edit_dhikr)) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = arabic,
                    onValueChange = { arabic = it },
                    label = { Text(stringResource(R.string.field_arabic)) },
                    isError = arabicError,
                    supportingText = { if (arabicError) Text(stringResource(R.string.error_required)) },
                    textStyle = TextStyle(textDirection = TextDirection.Rtl),
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(stringResource(R.string.field_title)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
                OutlinedTextField(
                    value = meaning,
                    onValueChange = { meaning = it },
                    label = { Text(stringResource(R.string.field_meaning)) },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
                OutlinedTextField(
                    value = count,
                    onValueChange = { count = it },
                    label = { Text(stringResource(R.string.field_suggested)) },
                    isError = countError,
                    supportingText = { if (countError) Text(stringResource(R.string.error_number)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                tried = true
                if (arabic.isNotBlank() && countValue != null && countValue in 1..1_000_000) {
                    onSave(arabic, title, countValue, meaning)
                }
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}
