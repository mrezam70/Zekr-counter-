package com.example.zekr.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.zekr.R
import com.example.zekr.data.settings.DarkMode
import com.example.zekr.data.settings.SettingsRepository
import com.example.zekr.data.theme.ThemeRepository
import com.example.zekr.data.theme.resolvePalette
import com.example.zekr.data.theme.themeDisplayName
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settingsRepo: SettingsRepository,
    themeRepo: ThemeRepository,
    onOpenThemes: () -> Unit,
) {
    val settings by settingsRepo.state.collectAsStateWithLifecycle()
    val custom by themeRepo.custom.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val palette = resolvePalette(settings.themeId, custom)
    var sens by remember(settings.sensitivity) { mutableFloatStateOf(settings.sensitivity.toFloat()) }
    val surface = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionTitle(stringResource(R.string.settings_appearance))
        Card(colors = surface, modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenThemes).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                        listOf(palette.p, palette.m, palette.l).forEach { c ->
                            androidx.compose.foundation.layout.Box(
                                Modifier.size(24.dp).clip(CircleShape).background(c),
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
                        Text(stringResource(R.string.settings_theme), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(themeDisplayName(settings.themeId, custom), style = MaterialTheme.typography.titleSmall)
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
                Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                    Text(stringResource(R.string.settings_dark_mode), style = MaterialTheme.typography.titleSmall)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 8.dp),
                    ) {
                        listOf(
                            DarkMode.SYSTEM to R.string.dark_system,
                            DarkMode.LIGHT to R.string.dark_light,
                            DarkMode.DARK to R.string.dark_dark,
                        ).forEach { (mode, label) ->
                            FilterChip(
                                selected = settings.darkMode == mode,
                                onClick = { scope.launch { settingsRepo.setDarkMode(mode) } },
                                label = { Text(stringResource(label)) },
                            )
                        }
                    }
                }
            }
        }

        SectionTitle(stringResource(R.string.settings_counting))
        Card(colors = surface, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                SwitchRow(
                    title = stringResource(R.string.settings_vibration),
                    hint = null,
                    checked = settings.vibration,
                    onChange = { scope.launch { settingsRepo.setVibration(it) } },
                )
                SwitchRow(
                    title = stringResource(R.string.settings_volume_keys),
                    hint = stringResource(R.string.settings_volume_hint),
                    checked = settings.volumeKeys,
                    onChange = { scope.launch { settingsRepo.setVolumeKeys(it) } },
                )
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(stringResource(R.string.settings_sensitivity), style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = stringResource(
                                when (sens.toInt()) {
                                    1 -> R.string.sens_low
                                    3 -> R.string.sens_high
                                    else -> R.string.sens_medium
                                },
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Slider(
                        value = sens,
                        onValueChange = { sens = it },
                        onValueChangeFinished = { scope.launch { settingsRepo.setSensitivity(sens.toInt()) } },
                        valueRange = 1f..3f,
                        steps = 1,
                    )
                    Text(
                        text = stringResource(R.string.sens_hint),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 4.dp),
    )
}

@Composable
private fun SwitchRow(title: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            if (hint != null) {
                Text(hint, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
