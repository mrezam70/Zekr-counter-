package com.example.zekr.feature.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.zekr.R
import com.example.zekr.core.toLocalizedDigits
import com.example.zekr.data.repo.DhikrRepository

@Composable
fun DhikrDetailScreen(
    repo: DhikrRepository,
    id: Long,
    onBack: () -> Unit,
    onStart: (dhikrId: Long, goal: Int, intention: String?) -> Unit,
) {
    val vm: DhikrViewModel = viewModel(key = "detail", factory = DhikrViewModel.factory(repo))
    val items by vm.items.collectAsStateWithLifecycle()
    val item = items.firstOrNull { it.dhikr.id == id } ?: return
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language

    var goal by remember(id) { mutableStateOf(item.dhikr.suggestedCount) }
    var intention by remember(id) { mutableStateOf("") }
    var showEdit by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = item.dhikr.arabicText,
                    style = MaterialTheme.typography.headlineSmall.copy(textDirection = TextDirection.Rtl),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                item.meaning(lang)?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    )
                }
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(item.nameOf(ctx), style = MaterialTheme.typography.titleMedium)
                Text(
                    text = stringResource(R.string.suggested_count, item.dhikr.suggestedCount.toLocalizedDigits(lang)),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        // انتخاب هدف و نیت و شروع شمارش
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.goal_label), style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(33, 100, 313, 1000).forEach { g ->
                        FilterChip(
                            selected = goal == g,
                            onClick = { goal = g },
                            label = { Text(g.toLocalizedDigits(lang)) },
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    FilledIconButton(onClick = { goal = (goal - 1).coerceAtLeast(1) }) {
                        Icon(Icons.Filled.Remove, contentDescription = stringResource(R.string.decrease))
                    }
                    Text(goal.toLocalizedDigits(lang), style = MaterialTheme.typography.headlineSmall)
                    FilledIconButton(onClick = { goal = (goal + 1).coerceAtMost(1_000_000) }) {
                        Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.increase))
                    }
                }
                OutlinedTextField(
                    value = intention,
                    onValueChange = { intention = it },
                    label = { Text(stringResource(R.string.intention_label)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { onStart(id, goal, intention) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(stringResource(R.string.start_counting)) }
            }
        }
        // ذکرهای آماده قابل ویرایش و حذف نیستند؛ فقط ذکرهای دلخواه کاربر.
        if (item.dhikr.isCustom) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { showEdit = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Edit, contentDescription = null)
                    Text(stringResource(R.string.edit), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(
                    onClick = { showDelete = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.Delete, contentDescription = null)
                    Text(stringResource(R.string.delete), modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
    }

    if (showEdit) {
        DhikrEditDialog(
            initial = item,
            lang = lang,
            onDismiss = { showEdit = false },
            onSave = { arabic, title, suggested, meaning ->
                vm.update(id, arabic, title, suggested, lang, meaning)
                showEdit = false
            },
        )
    }
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text(stringResource(R.string.delete_title)) },
            text = { Text(stringResource(R.string.delete_text)) },
            confirmButton = {
                TextButton(onClick = {
                    showDelete = false
                    vm.delete(id)
                    onBack()
                }) { Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}
