package com.example.zekr.data.repo

import com.example.zekr.data.local.DhikrDao
import com.example.zekr.data.local.DhikrEntity
import com.example.zekr.data.local.DhikrTranslation
import com.example.zekr.data.local.DhikrWithTranslations
import com.example.zekr.data.local.SeedData
import kotlinx.coroutines.flow.Flow

class DhikrRepository(private val dao: DhikrDao) {

    fun observeAll(): Flow<List<DhikrWithTranslations>> = dao.observeAll()

    /** بار اول اجرا، ذکرهای آماده را وارد دیتابیس می‌کند. */
    suspend fun seedIfEmpty() {
        if (dao.count() > 0) {
            refreshSeedTranslations()
            return
        }
        SeedData.items.forEach { item ->
            val id = dao.insert(
                DhikrEntity(
                    builtinKey = item.key,
                    arabicText = item.arabic,
                    category = item.category,
                    suggestedCount = item.suggested,
                ),
            )
            dao.upsertTranslations(item.meanings.map { (lang, meaning) -> DhikrTranslation(id, lang, meaning) })
        }
    }

    /** معنی ذکرهای آماده را به‌روز می‌کند تا زبان‌های جدید به نصب‌های قبلی هم برسند. */
    private suspend fun refreshSeedTranslations() {
        SeedData.items.forEach { item ->
            val id = dao.getByKey(item.key)?.id ?: return@forEach
            dao.upsertTranslations(item.meanings.map { (lang, meaning) -> DhikrTranslation(id, lang, meaning) })
        }
    }

    /** افزودن ذکر دلخواه. معنی (اختیاری) به زبان فعلی برنامه ذخیره می‌شود. */
    suspend fun addCustom(arabic: String, title: String?, suggested: Int, lang: String, meaning: String?): Long {
        val id = dao.insert(
            DhikrEntity(
                arabicText = arabic.trim(),
                title = title?.trim()?.takeIf { it.isNotEmpty() },
                category = "custom",
                suggestedCount = suggested,
                isCustom = true,
            ),
        )
        saveMeaning(id, lang, meaning)
        return id
    }

    suspend fun updateCustom(id: Long, arabic: String, title: String?, suggested: Int, lang: String, meaning: String?) {
        val old = dao.getById(id) ?: return
        if (!old.isCustom) return
        dao.update(
            old.copy(
                arabicText = arabic.trim(),
                title = title?.trim()?.takeIf { it.isNotEmpty() },
                suggestedCount = suggested,
            ),
        )
        saveMeaning(id, lang, meaning)
    }

    suspend fun deleteCustom(id: Long) = dao.deleteCustom(id)

    private suspend fun saveMeaning(id: Long, lang: String, meaning: String?) {
        val m = meaning?.trim().orEmpty()
        if (m.isEmpty()) dao.deleteTranslation(id, lang)
        else dao.upsertTranslations(listOf(DhikrTranslation(id, lang, m)))
    }
}
