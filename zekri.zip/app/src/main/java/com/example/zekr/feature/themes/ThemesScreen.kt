package com.example.zekr.feature.themes

import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.zekr.R
import com.example.zekr.data.settings.SettingsRepository
import com.example.zekr.data.theme.CatalogItem
import com.example.zekr.data.theme.ImportResult
import com.example.zekr.data.theme.ThemeRepository
import com.example.zekr.data.theme.toPalette
import com.example.zekr.ui.theme.BuiltInThemes
import com.example.zekr.ui.theme.ThemePalette
import kotlinx.coroutines.launch

private class Msg(@StringRes val res: Int, val arg: String? = null, val error: Boolean)

private sealed class CatalogState {
    object Idle : CatalogState()
    object Loading : CatalogState()
    object Failed : CatalogState()
    class Loaded(val items: List<CatalogItem>) : CatalogState()
}

@Composable
fun ThemesScreen(settingsRepo: SettingsRepository, themeRepo: ThemeRepository) {
    val settings by settingsRepo.state.collectAsStateWithLifecycle()
    val custom by themeRepo.custom.collectAsStateWithLifecycle(initialValue = emptyList())
    val lang = LocalConfiguration.current.locales[0].language
    val scope = rememberCoroutineScope()

    var url by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<Msg?>(null) }
    var catalog by remember { mutableStateOf<CatalogState>(CatalogState.Idle) }

    fun import(link: String) {
        scope.launch {
            working = true
            msg = null
            val result = themeRepo.importFromUrl(link, lang)
            working = false
            msg = when (result) {
                ImportResult.Success -> {
                    url = ""
                    Msg(R.string.themes_added, null, error = false)
                }
                ImportResult.BadUrl -> Msg(R.string.theme_err_url, null, true)
                ImportResult.Network -> Msg(R.string.theme_err_network, null, true)
                ImportResult.Limit -> Msg(R.string.theme_err_limit, null, true)
                is ImportResult.Invalid -> Msg(R.string.theme_err_invalid, result.reason, true)
                is ImportResult.Contrast -> Msg(R.string.theme_err_contrast, result.reason, true)
            }
        }
    }

    Column(
        modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Title(stringResource(R.string.themes_builtin))
        BuiltInThemes.all.forEach { p ->
            ThemeCard(
                palette = p,
                name = stringResource(BuiltInThemes.nameRes(p.id)!!),
                selected = settings.themeId == p.id,
                onSelect = { scope.launch { settingsRepo.setTheme(p.id) } },
                onDelete = null,
            )
        }

        Title(stringResource(R.string.themes_mine))
        if (custom.isEmpty()) {
            Text(
                stringResource(R.string.themes_mine_empty),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
            )
        }
        custom.forEach { t ->
            ThemeCard(
                palette = t.toPalette(),
                name = t.name,
                selected = settings.themeId == t.id,
                onSelect = { scope.launch { settingsRepo.setTheme(t.id) } },
                onDelete = {
                    scope.launch {
                        themeRepo.delete(t.id)
                        if (settings.themeId == t.id) settingsRepo.setTheme(BuiltInThemes.green.id)
                    }
                },
            )
        }

        Title(stringResource(R.string.themes_add))
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; msg = null },
                    label = { Text(stringResource(R.string.themes_url_label)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = { import(url) },
                    enabled = !working && url.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (working) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text(stringResource(R.string.themes_import))
                    }
                }
                msg?.let {
                    Text(
                        text = if (it.arg != null) stringResource(it.res, it.arg) else stringResource(it.res),
                        color = if (it.error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp,
                    )
                }
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            catalog = CatalogState.Loading
                            val items = themeRepo.fetchCatalog()
                            catalog = if (items == null) CatalogState.Failed else CatalogState.Loaded(items)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(stringResource(R.string.themes_browse)) }

                when (val c = catalog) {
                    CatalogState.Idle -> Unit
                    CatalogState.Loading -> CircularProgressIndicator(
                        modifier = Modifier.size(24.dp).align(Alignment.CenterHorizontally),
                        strokeWidth = 2.dp,
                    )
                    CatalogState.Failed -> Text(
                        stringResource(R.string.themes_catalog_error),
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp,
                    )
                    is CatalogState.Loaded -> {
                        if (c.items.isEmpty()) {
                            Text(
                                stringResource(R.string.themes_catalog_empty),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp,
                            )
                        }
                        c.items.forEach { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(item.name, modifier = Modifier.weight(1f))
                                TextButton(onClick = { import(item.url) }, enabled = !working) {
                                    Text(stringResource(R.string.themes_download))
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(
            text = stringResource(R.string.themes_safe),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Title(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 4.dp),
    )
}

@Composable
private fun ThemeCard(
    palette: ThemePalette,
    name: String,
    selected: Boolean,
    onSelect: () -> Unit,
    onDelete: (() -> Unit)?,
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect),
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy((-6).dp)) {
                listOf(palette.p, palette.m, palette.l, palette.x9).forEach { c ->
                    Box(Modifier.size(26.dp).clip(CircleShape).background(c))
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
                Text(name, style = MaterialTheme.typography.titleSmall)
                if (selected) {
                    Text(
                        stringResource(R.string.themes_selected),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
            }
            if (selected) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(
                        Icons.Filled.Delete,
                        contentDescription = stringResource(R.string.themes_delete_cd),
                        tint = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }
    }
}
