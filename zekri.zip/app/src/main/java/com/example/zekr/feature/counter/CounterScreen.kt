package com.example.zekr.feature.counter

import android.os.SystemClock
import androidx.annotation.StringRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.zekr.R
import com.example.zekr.ZekrApp
import com.example.zekr.data.settings.SettingsRepository
import com.example.zekr.core.toAsciiDigits
import com.example.zekr.core.toLocalizedDigits
import com.example.zekr.data.repo.CounterRepository
import com.example.zekr.data.repo.DhikrRepository
import com.example.zekr.feature.library.nameOf
import kotlinx.coroutines.launch

/**
 * صفحه شمارش. لمس هر نقطه از صفحه یک شمارش ثبت می‌کند؛
 * دکمه‌ها رویداد لمس خودشان را مصرف می‌کنند و شمارش نمی‌شوند.
 */
@Composable
fun CounterScreen(counters: CounterRepository, dhikrRepo: DhikrRepository, settingsRepo: SettingsRepository) {
    val vm: CounterViewModel = viewModel(factory = CounterViewModel.factory(counters, dhikrRepo))
    val ui by vm.ui.collectAsStateWithLifecycle()
    val uiNow by rememberUpdatedState(ui)
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language
    val haptic = LocalHapticFeedback.current
    val settings by settingsRepo.state.collectAsStateWithLifecycle()
    val settingsNow by rememberUpdatedState(settings)
    val lastTap = remember { LongArray(1) }

    // به MainActivity می‌گوید صفحه شمارش جلوی کاربر است (برای شمارش با دکمه‌های ولوم)
    val container = (ctx.applicationContext as ZekrApp).container
    DisposableEffect(Unit) {
        container.counterScreenActive = true
        onDispose { container.counterScreenActive = false }
    }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showReset by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }

    fun say(@StringRes id: Int) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(ctx.getString(id))
        }
    }

    val onPrimary = MaterialTheme.colorScheme.onPrimary
    val primary = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(primary)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    val s = uiNow
                    val prefs = settingsNow
                    // حساسیت کم: لمس‌های پشت‌سرهم خیلی سریع نادیده گرفته می‌شوند
                    val minGap = when (prefs.sensitivity) {
                        1 -> 220L
                        2 -> 80L
                        else -> 0L
                    }
                    val now = SystemClock.elapsedRealtime()
                    if (s.ready && now - lastTap[0] >= minGap) {
                        lastTap[0] = now
                        vm.increment()
                        if (prefs.vibration) {
                            // لرزش قوی‌تر وقتی به هدف می‌رسیم
                            haptic.performHapticFeedback(
                                if (s.count + 1 == s.goal) HapticFeedbackType.LongPress
                                else HapticFeedbackType.TextHandleMove,
                            )
                        }
                    }
                })
            },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // انتخاب سریع ذکر
            LazyRow(
                contentPadding = PaddingValues(horizontal = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(ui.allDhikr, key = { it.dhikr.id }) { item ->
                    val selected = item.dhikr.id == ui.dhikr?.dhikr?.id
                    Surface(
                        onClick = { if (!selected) vm.selectDhikr(item) },
                        shape = RoundedCornerShape(16.dp),
                        color = if (selected) onPrimary else onPrimary.copy(alpha = 0.16f),
                    ) {
                        Text(
                            text = item.nameOf(ctx),
                            color = if (selected) primary else onPrimary,
                            fontSize = 13.sp,
                            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
            }

            ui.dhikr?.let {
                Text(
                    text = it.dhikr.arabicText,
                    color = onPrimary,
                    fontSize = 19.sp,
                    lineHeight = 32.sp,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Rtl),
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                )
            }

            Box(modifier = Modifier.padding(top = 8.dp)) {
                ProgressRing(count = ui.count, goal = ui.goal, lang = lang, color = onPrimary)
            }

            val reached = ui.ready && ui.count >= ui.goal
            val intention = ui.intention
            Text(
                text = when {
                    reached -> stringResource(R.string.goal_reached)
                    !intention.isNullOrBlank() -> stringResource(R.string.intention_line, intention)
                    else -> ""
                },
                color = onPrimary,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp).height(22.dp),
            )

            Row(
                modifier = Modifier.padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                ToolButton(
                    icon = Icons.AutoMirrored.Filled.Undo,
                    label = stringResource(R.string.undo),
                    badge = if (ui.undoCount > 0) ui.undoCount.toLocalizedDigits(lang) else null,
                    onClick = { if (ui.undoCount == 0) say(R.string.msg_undo_none) else vm.undo() },
                )
                ToolButton(
                    icon = Icons.Filled.Edit,
                    label = stringResource(R.string.edit_count),
                    onClick = { showEdit = true },
                )
                ToolButton(
                    icon = if (ui.locked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                    label = stringResource(R.string.reset_lock),
                    active = ui.locked,
                    onClick = { vm.setLocked(!ui.locked) },
                )
                ToolButton(
                    icon = Icons.Filled.Refresh,
                    label = stringResource(R.string.reset),
                    onClick = {
                        when {
                            ui.locked -> say(R.string.msg_locked)
                            ui.count == 0 -> say(R.string.msg_nothing)
                            else -> showReset = true
                        }
                    },
                )
            }

            Surface(
                onClick = {
                    if (ui.count == 0) say(R.string.msg_nothing)
                    else {
                        vm.endSession()
                        say(R.string.msg_saved)
                    }
                },
                shape = RoundedCornerShape(12.dp),
                color = onPrimary.copy(alpha = 0.18f),
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp).height(44.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Flag, contentDescription = null, tint = onPrimary)
                    Text(
                        text = stringResource(R.string.end_session),
                        color = onPrimary,
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = onPrimary.copy(alpha = 0.16f),
                modifier = Modifier.padding(top = 20.dp, bottom = 8.dp),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.PanTool, contentDescription = null, tint = onPrimary, modifier = Modifier.size(18.dp))
                    Text(
                        text = stringResource(R.string.tap_hint),
                        color = onPrimary,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(start = 6.dp),
                    )
                }
            }
        }

        SnackbarHost(hostState = snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text(stringResource(R.string.reset_title)) },
            text = { Text(stringResource(R.string.reset_text, ui.count.toLocalizedDigits(lang))) },
            confirmButton = {
                TextButton(onClick = {
                    showReset = false
                    vm.reset()
                    say(R.string.msg_reset_done)
                }) { Text(stringResource(R.string.yes_reset), color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }

    if (showEdit) {
        EditCountDialog(
            current = ui.count,
            lang = lang,
            onDismiss = { showEdit = false },
            onSave = {
                vm.setCount(it)
                showEdit = false
            },
        )
    }
}

@Composable
private fun EditCountDialog(current: Int, lang: String, onDismiss: () -> Unit, onSave: (Int) -> Unit) {
    var text by remember { mutableStateOf(current.toLocalizedDigits(lang)) }
    var tried by remember { mutableStateOf(false) }
    val value = text.toAsciiDigits().trim().toIntOrNull()
    val bad = value == null || value !in 0..CounterRepository.MAX_COUNT

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.edit_title)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                isError = tried && bad,
                supportingText = { if (tried && bad) Text(stringResource(R.string.error_count)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = {
                tried = true
                if (!bad) onSave(value!!)
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}

@Composable
private fun ProgressRing(count: Int, goal: Int, lang: String, color: Color) {
    val target = (count.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)
    val progress by animateFloatAsState(targetValue = target, label = "ring")
    Box(modifier = Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            val inset = stroke.width / 2
            val arcSize = Size(size.width - stroke.width, size.height - stroke.width)
            drawArc(color.copy(alpha = 0.25f), 0f, 360f, false, Offset(inset, inset), arcSize, style = stroke)
            drawArc(color, -90f, 360f * progress, false, Offset(inset, inset), arcSize, style = stroke)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = count.toLocalizedDigits(lang),
                color = color,
                fontSize = 56.sp,
                fontWeight = FontWeight.Medium,
            )
            Text(
                text = stringResource(R.string.of_goal, goal.toLocalizedDigits(lang)),
                color = color.copy(alpha = 0.9f),
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    active: Boolean = false,
    badge: String? = null,
) {
    val onPrimary = MaterialTheme.colorScheme.onPrimary
    val primary = MaterialTheme.colorScheme.primary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
        Box {
            Surface(
                onClick = onClick,
                shape = CircleShape,
                color = if (active) onPrimary else onPrimary.copy(alpha = 0.18f),
                modifier = Modifier.size(54.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = label, tint = if (active) primary else onPrimary)
                }
            }
            if (badge != null) {
                Surface(
                    shape = CircleShape,
                    color = onPrimary,
                    modifier = Modifier.align(Alignment.TopEnd),
                ) {
                    Text(
                        text = badge,
                        color = primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                }
            }
        }
        Text(
            text = label,
            color = onPrimary,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
