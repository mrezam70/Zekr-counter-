package com.example.zekr.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.zekr.data.local.OutboxDao
import com.example.zekr.data.local.OutboxEntry
import com.example.zekr.data.local.ThemeDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import org.json.JSONArray
import org.json.JSONObject

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

enum class DarkMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val themeId: String = "green",
    val darkMode: DarkMode = DarkMode.SYSTEM,
    val vibration: Boolean = true,
    /** شمارش با دکمه‌های ولوم؛ پیش‌فرض خاموش چون کنترل ولوم را از کاربر می‌گیرد. */
    val volumeKeys: Boolean = false,
    /** ۱ = کم، ۲ = متوسط، ۳ = زیاد */
    val sensitivity: Int = 2,
)

/**
 * تنظیمات برنامه روی گوشی (DataStore). هر تغییر در صف ارسال به سرور هم ثبت می‌شود
 * (فقط آخرین نسخه نگه داشته می‌شود) و بعد از ورود کاربر به سرور می‌رود.
 */
class SettingsRepository(
    private val context: Context,
    scope: CoroutineScope,
    private val outbox: OutboxDao,
    private val themes: ThemeDao,
    private val onOutboxChanged: () -> Unit,
) {
    private object Keys {
        val THEME = stringPreferencesKey("theme_id")
        val DARK = stringPreferencesKey("dark_mode")
        val VIBRATION = booleanPreferencesKey("vibration")
        val VOLUME = booleanPreferencesKey("volume_keys")
        val SENS = intPreferencesKey("sensitivity")
    }

    val state: StateFlow<AppSettings> = context.settingsStore.data
        .map { it.toSettings() }
        .stateIn(scope, SharingStarted.Eagerly, AppSettings())

    suspend fun setTheme(id: String) = update { it[Keys.THEME] = id }
    suspend fun setDarkMode(mode: DarkMode) = update { it[Keys.DARK] = mode.name }
    suspend fun setVibration(on: Boolean) = update { it[Keys.VIBRATION] = on }
    suspend fun setVolumeKeys(on: Boolean) = update { it[Keys.VOLUME] = on }
    suspend fun setSensitivity(level: Int) = update { it[Keys.SENS] = level.coerceIn(1, 3) }

    /** تنظیمات (و آدرس تم‌های دانلودی) را برای ارسال به سرور در صف می‌گذارد. */
    suspend fun enqueueSync() {
        val s = context.settingsStore.data.first().toSettings()
        val urls = JSONArray().also { arr -> themes.sourceUrls().forEach { arr.put(it) } }
        val payload = JSONObject()
            .put("themeId", s.themeId)
            .put("darkMode", s.darkMode.name)
            .put("vibration", s.vibration)
            .put("volumeKeys", s.volumeKeys)
            .put("sensitivity", s.sensitivity)
            .put("customThemeUrls", urls)
            .put("updatedAt", System.currentTimeMillis())
        // شناسه ثابت: نسخه جدید جایگزین نسخه قدیمی در صف می‌شود
        outbox.insert(OutboxEntry(id = "settings", type = "settings", payloadJson = payload.toString()))
        onOutboxChanged()
    }

    private suspend fun update(block: (MutablePreferences) -> Unit) {
        context.settingsStore.edit { block(it) }
        enqueueSync()
    }

    private fun Preferences.toSettings() = AppSettings(
        themeId = this[Keys.THEME] ?: "green",
        darkMode = this[Keys.DARK]?.let { runCatching { DarkMode.valueOf(it) }.getOrNull() } ?: DarkMode.SYSTEM,
        vibration = this[Keys.VIBRATION] ?: true,
        volumeKeys = this[Keys.VOLUME] ?: false,
        sensitivity = this[Keys.SENS] ?: 2,
    )
}
