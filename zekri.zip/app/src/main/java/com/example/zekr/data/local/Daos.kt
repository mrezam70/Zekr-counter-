package com.example.zekr.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DhikrDao {
    @Transaction
    @Query("SELECT * FROM dhikr ORDER BY isCustom ASC, id ASC")
    fun observeAll(): Flow<List<DhikrWithTranslations>>

    @Query("SELECT * FROM dhikr WHERE id = :id")
    suspend fun getById(id: Long): DhikrEntity?

    @Query("SELECT COUNT(*) FROM dhikr")
    suspend fun count(): Int

    @Query("SELECT * FROM dhikr ORDER BY id ASC LIMIT 1")
    suspend fun getFirst(): DhikrEntity?

    @Query("SELECT * FROM dhikr WHERE builtinKey = :key LIMIT 1")
    suspend fun getByKey(key: String): DhikrEntity?

    @Insert
    suspend fun insert(d: DhikrEntity): Long

    @Update
    suspend fun update(d: DhikrEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTranslations(items: List<DhikrTranslation>)

    @Query("DELETE FROM dhikr_translation WHERE dhikrId = :id AND lang = :lang")
    suspend fun deleteTranslation(id: Long, lang: String)

    /** فقط ذکرهای دلخواه حذف می‌شوند؛ ذکرهای آماده محافظت‌شده‌اند. */
    @Query("DELETE FROM dhikr WHERE id = :id AND isCustom = 1")
    suspend fun deleteCustom(id: Long)
}

@Dao
interface CounterDao {
    @Query("SELECT * FROM counter_state WHERE id = 1")
    fun observe(): Flow<CounterState?>

    @Query("SELECT * FROM counter_state WHERE id = 1")
    suspend fun get(): CounterState?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(state: CounterState)

    @Insert
    suspend fun pushUndo(u: CounterUndo)

    @Query("SELECT * FROM counter_undo ORDER BY id DESC LIMIT 1")
    suspend fun peekUndo(): CounterUndo?

    @Query("DELETE FROM counter_undo WHERE id = :id")
    suspend fun deleteUndo(id: Long)

    @Query("DELETE FROM counter_undo")
    suspend fun clearUndo()

    @Query("SELECT COUNT(*) FROM counter_undo")
    fun observeUndoCount(): Flow<Int>

    @Query("DELETE FROM counter_undo WHERE id NOT IN (SELECT id FROM counter_undo ORDER BY id DESC LIMIT 50)")
    suspend fun trimUndo()
}

@Dao
interface SessionDao {
    @Insert
    suspend fun insert(s: SessionHistory)

    @Query("SELECT * FROM session_history ORDER BY endedAt DESC")
    fun observeAll(): Flow<List<SessionHistory>>

    @Query("SELECT * FROM session_history WHERE endedAt >= :since ORDER BY endedAt DESC")
    fun observeSince(since: Long): Flow<List<SessionHistory>>

    @Query("UPDATE session_history SET syncState = 'synced' WHERE id IN (:ids)")
    suspend fun markSynced(ids: List<String>)
}

@Dao
interface OutboxDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(e: OutboxEntry)

    @Query("SELECT * FROM outbox ORDER BY createdAt ASC LIMIT :limit")
    suspend fun pending(limit: Int): List<OutboxEntry>

    @Query("DELETE FROM outbox WHERE id IN (:ids)")
    suspend fun delete(ids: List<String>)

    @Query("UPDATE outbox SET attempts = attempts + 1, lastError = :error WHERE id IN (:ids)")
    suspend fun bumpAttempts(ids: List<String>, error: String?)

    @Query("SELECT COUNT(*) FROM outbox")
    fun observeCount(): Flow<Int>
}

@Dao
interface KhatmDao {
    @Query("SELECT * FROM khatm ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<KhatmEntity>>

    @Query("SELECT * FROM khatm WHERE id = :id")
    fun observeById(id: Long): Flow<KhatmEntity?>

    @Query("SELECT * FROM khatm WHERE id = :id")
    suspend fun getById(id: Long): KhatmEntity?

    @Insert
    suspend fun insert(k: KhatmEntity): Long

    @Update
    suspend fun update(k: KhatmEntity)

    @Query("DELETE FROM khatm WHERE id = :id")
    suspend fun delete(id: Long)

    @Insert
    suspend fun insertContribution(c: KhatmContribution)

    @Query("SELECT * FROM khatm_contribution WHERE khatmId = :khatmId ORDER BY createdAt DESC")
    fun observeContributions(khatmId: Long): Flow<List<KhatmContribution>>
}

@Dao
interface ThemeDao {
    @Query("SELECT * FROM custom_theme ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<ThemeEntity>>

    @Query("SELECT COUNT(*) FROM custom_theme")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM custom_theme WHERE id = :id")
    suspend fun exists(id: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(t: ThemeEntity)

    @Query("DELETE FROM custom_theme WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT sourceUrl FROM custom_theme WHERE sourceUrl IS NOT NULL")
    suspend fun sourceUrls(): List<String>
}
