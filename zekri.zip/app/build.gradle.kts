plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.example.zekr"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.zekr"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"

        // آدرس سرور. بعد از ساخت سرور، اینجا آدرس واقعی گذاشته می‌شود (با / در انتها).
        buildConfigField("String", "SERVER_URL", "\"https://api.example.com/\"")

        // فهرست آنلاین تم‌ها (فایل JSON). بعد از ساخت سایت تم‌ها، آدرس واقعی اینجا گذاشته می‌شود.
        buildConfigField("String", "THEMES_CATALOG_URL", "\"https://example.com/zekr-themes/index.json\"")

        // ایمیل بخش «ارتباط با ما»
        buildConfigField("String", "CONTACT_EMAIL", "\"mrezam90@gmail.com\"")
    }

    androidResources {
        localeFilters += listOf("fa", "ar", "en", "ur", "zh", "ja", "ko")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.work.runtime)
    implementation(libs.square.okhttp)
    implementation(libs.google.material)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons.extended)
    debugImplementation(libs.compose.ui.tooling)
}
