# قالب فایل تم (برای سایت دانلود تم‌ها)

تم یک فایل **JSON** است. فقط **رنگ** تعیین می‌کند و هیچ کدی اجرا نمی‌شود.
حجم فایل حداکثر ۱۶ کیلوبایت و آدرس باید `https` باشد.

```json
{
  "schema": 1,
  "id": "sunset-rose",
  "name": { "fa": "گل غروب", "en": "Sunset rose", "ar": "وردة الغروب" },
  "colors": {
    "primary": "#993556",
    "primaryDark": "#D4537E",
    "background": "#FBEAF0",
    "container": "#F4C0D1",
    "onContainer": "#72243E",
    "containerDark": "#72243E",
    "onContainerDark": "#F4C0D1",
    "backgroundDark": "#4B1528"
  }
}
```

| فیلد | معنی |
|---|---|
| `schema` | همیشه `1` |
| `id` | شناسه یکتا: حروف کوچک انگلیسی، عدد و خط تیره، ۳ تا ۴۰ نویسه. با تم‌های آماده (`green`, `blue`, `amber`) نباید یکی باشد |
| `name` | متن یا نقشه زبان← نام (حداکثر ۳۰ نویسه) |
| `primary` / `primaryDark` | رنگ اصلی (نوار بالا و دکمه‌ها) در حالت روشن / تیره |
| `background` / `backgroundDark` | پس‌زمینه صفحه |
| `container` / `containerDark` | رنگ چیپ‌ها و کارت‌های رنگی |
| `onContainer` / `onContainerDark` | رنگ متن روی کانتینر |

همه رنگ‌ها به شکل `#RRGGBB`.

## بررسی خوانایی (خودکار، موقع افزودن)
اگر یکی از این‌ها رد شود، تم اضافه نمی‌شود و اپ می‌گوید کدام رنگ مشکل دارد:

- متن سفید روی `primary` و `primaryDark`: حداقل کنتراست ۳
- `onContainer` روی `container` و `onContainerDark` روی `containerDark`: حداقل ۴٫۵
- متن تیره روی `background`: حداقل ۷؛ متن روشن روی `backgroundDark`: حداقل ۷
- `primaryDark` روی `backgroundDark`: حداقل ۳

## فهرست آنلاین (اختیاری)
آدرس فایل فهرست در `app/build.gradle.kts` (مقدار `THEMES_CATALOG_URL`) تنظیم می‌شود:

```json
{
  "themes": [
    { "id": "sunset-rose", "name": "Sunset rose", "url": "https://example.com/zekr-themes/sunset-rose.json" }
  ]
}
```

حداکثر ۵۰ تم در فهرست خوانده می‌شود. کاربر هم می‌تواند مستقیم لینک یک فایل تم را وارد کند.
یک نمونه آماده در `docs/sample-theme.json` است. برای میزبانی می‌توانید از GitHub Pages یا هر هاست https دیگر استفاده کنید.
